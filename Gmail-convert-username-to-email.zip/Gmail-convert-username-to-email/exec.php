

                      <?php
    
	                     //below variables are being assign to names of input fields in the registration form.
	                     session_start();
                         include('connection.php');
    
	                   $firstname=$_POST['firstname'];
                       $secondname=$_POST['secondname'];
                       $email=$_POST['email'];
	                   $sex=$_POST['sex'];
                       $password=$_POST['password'];
	                   $photo=$_POST['profile_picture'];
	                   $day=$_POST['day'];
	                   $month=$_POST['month'];
	                   $year=$_POST['year'];
	
					   $fmail = "$email@gmail.com";
					 
					 $smail= "$fmail";
					 
					   if(strpos($email, '@'))
					 
					    {
						
						  echo"<p style='color:;'> Please don't add <span style='color:green;'> @</span> in your email. It is not accepted.<br>
						  Input only the names which will be used for your email.</p>";
						 
						}else
						
						{
	
	                        echo"<p style='color:;'> Your prospect email is <span style='color:green;'>$email@gmail.com</span></p>";
						
							$query = mysql_query("SELECT * FROM member WHERE email='$smail'");
         
		                          if(mysql_num_rows($query) > 0)
		 
		                            {
   
                                   echo"<p style='color:red;'> This <span style='color:green;'>$email@gmail.com</span> email already exist. </p>";

                                    }else 
				 
	                                 {
	   
	                            //Below insert the registered user information into the database when it has passed the above validation.
	
                                  mysql_query("INSERT INTO member(firstname, secondname, email, sex, password, profile_picture, day, month, year)
	                                VALUES( '$firstname', '$secondname', '$smail', '$sex', '$password', '$photo', '$day', '$month', '$year')");
                                     header("location:home.php");
                                    mysql_close($con);
	
	                            //Create query
    
	                           $qry="SELECT * FROM member WHERE email='$smail' AND password='$password'";
                                 $result=mysql_query($qry);
     
                              //Check whether the query was successful or not
                 
	                              if($result) 
	
	                              {
       
	                               if(mysql_num_rows($result) > 0) 
		
                                  {
                                    //register Successful
                                      session_regenerate_id();
                                      $member = mysql_fetch_assoc($result);
                                      $_SESSION['SESS_MEMBER_ID'] = $member['member_id'];
                                      $_SESSION['SESS_FIRST_NAME'] = $member['email'];
                                      $_SESSION['SESS_LAST_NAME'] = $member['password'];
                                      session_write_close();
                                        exit();
	        
			
	                                  }
                                    }
                                  }
                                } 
	                 
					             ?>
	
	
     