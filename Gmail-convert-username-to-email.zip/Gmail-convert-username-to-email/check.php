

                <?php
       
	   
	                 include('connection.php');
	  
	 
					 $var= $_POST['email'];
					 
					 $email = '@gmail.com';
						
					 $femail = "$var@gmail.com";
					 
					 $smail= "$femail";
					 
					   if(strpos($var, '@'))
					 
					    {
						
						  echo"<p style='color:;'> Please don't add <span style='color:green;'> @</span> in your email. It is not accepted.<br>
						  Input only the names which will be used for your email.</p>";
						 
						}else
						
						{
						
						echo"<p style='color:;'> Your prospect email is <span style='color:green;'>$smail</span></p>";
						
							$query = mysql_query("SELECT * FROM member WHERE email='$femail'");
         
		                          if(mysql_num_rows($query) > 0)
		 
		                            {
   
                                   echo"<p style='color:red;'> This <span style='color:green;'>$smail</span> email is taken. Try another </p>";

                                    }else 
				 
	                                 {
	   
	                               echo"<p style='color:red;'> This <span style='color:green;'>$smail</span> email has not be taken. </p>";
	   
	                                 }
						
						   }
					 
					 ?>
     