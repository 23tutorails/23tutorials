-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2016 at 05:51 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `script`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `secondname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `profile_picture` varchar(30) NOT NULL,
  `day` varchar(100) NOT NULL,
  `month` varchar(30) NOT NULL,
  `year` varchar(100) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `firstname`, `secondname`, `email`, `sex`, `password`, `profile_picture`, `day`, `month`, `year`) VALUES
(13, 'loyd', 'ima', 'ima@gmail.com', '', 'mmmm', 'p.jpg', '', '', ''),
(14, 'lano', 'demi', 'lano@gmail.com', '', 'mmmm', 'p.jpg', '', '', ''),
(15, 'jones', 'punto', 'punto@gmail.com', '', 'mmmm', 'p.jpg', '', '', ''),
(16, 'ibb', 'page', 'paul@gmail.com', '', 'jjjj', 'p.jpg', '', '', ''),
(17, 'thomas', 'ester', 'll@gmail.com', '', 'mmmm', 'p.jpg', '', '', ''),
(18, 'loo', 'hook', 'hh@gmail.com', '', 'mmmm', 'p.jpg', '', '', ''),
(19, 'root', 'goobi', 'goo@gmail.com', '', 'mmmm', 'p.jpg', '', '', ''),
(20, 'let', 'tum', 'let@gamil.com', '', 'mmmm', 'p.jpg', '', '', ''),
(48, 'samue', 'stone', 'rito@gmail.com', '', 'ssss', 'p.jpg', '', '', ''),
(50, 'paul', 'seeni', 'seeni@gmail.com', 'male', 'mmm', 'p.jpg', '1', 'January', '1924');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
