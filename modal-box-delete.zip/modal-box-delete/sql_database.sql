-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2016 at 04:26 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `script`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` varchar(5000) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageid`, `sender_id`, `receiver_id`, `message`, `date`) VALUES
(1, 11, 12, 'love dat', '2016-04-05'),
(2, 12, 11, 'God is great.', '2016-04-08'),
(3, 12, 11, 'it works.', '2016-04-08'),
(4, 11, 12, 'God is with me', '2016-04-08'),
(18, 11, 12, 'we love dat', '2016-04-08'),
(19, 11, 13, 'dat me boyz.', '2016-04-09'),
(20, 11, 12, 'i sent you a message', '2016-07-07'),
(21, 11, 12, 'love dat', '2016-07-07'),
(22, 11, 13, 'thanks man', '2016-07-07'),
(23, 20, 13, 'love God.', '2016-07-07'),
(24, 20, 13, 'God is able', '2016-07-07'),
(25, 20, 11, 'text me now', '2016-07-11');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
