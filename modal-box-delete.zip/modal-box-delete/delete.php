   
  
  
         <?php
 
          include("connection.php"); // connect to the database
		  
   		    $message_id = $_GET['id'];
	  
              $result = mysql_query("SELECT * FROM `messages` WHERE messageid ='$message_id' ");
               while($row = mysql_fetch_array($result))
                                  
			{
							   
				echo'<a href=delete.php?id='.$row['messageid'].' > '.$row['message'].'</a><br>';
				
				echo'<div class="delete-button"> <a href=delete-message.php?id='.$row['messageid'].'><p> Delete Message </p></a></div><br>';
                              
			}
								
								        
         ?> 
		 
		 
		 <script>
	   function cancel(){
	          var whitebg = document.getElementById("white-background");
			  var dlg = document.getElementById("dlgbox");
			  whitebg.style.display="none";
			  dlg.style.display="none";
			  
			  }
			  
	    </script>		  