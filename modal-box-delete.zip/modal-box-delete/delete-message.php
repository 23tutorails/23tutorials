   
  
  
         <?php
 
          include("connection.php"); // connect to the database
		  
   		    $message_id = $_GET['id'];
	  
              $result = mysql_query("delete FROM `messages` WHERE messageid ='$message_id' ");
              header("location:index.php");		
								        
         ?> 
		 
		  