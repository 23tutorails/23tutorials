   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>



       

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">23tutorials.com tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  
				 
				 <div id="messages">

				         <?php
                           
						   include("connection.php");
                                $result = mysql_query("SELECT * FROM `messages` ");
                                     while($row = mysql_fetch_array($result))
                                  
								     {
							   
							          
                                       echo'<a href=delete.php?id='.$row['messageid'].' class="result" onclick="showDialog()"> '.$row['message'].' </a><br>';
                              
								     }
								
								        
        
		                      ?> 
		
	                  </div>
					  
					  
					  
					  <div id="white-background">
	
	
	                       </div>
	
	<div id="dlgbox">
	    <div id="dlg-header">Delete this message</div>
		<div id="dlg-body">  </div>
		
		
	    <div id="dlg-footer">
            <button onclick="dlglogin()">Cancel</button>
          </div>
		  </div>
        
     <!-- rest of the page-->
	 
	 
	   <script>
	   function dlglogin(){
	          var whitebg = document.getElementById("white-background");
			  var dlg = document.getElementById("dlgbox");
			  whitebg.style.display="none";
			  dlg.style.display="none";
			  
			  }
			  
			  function showDialog(){
			  var whitebg = document.getElementById("white-background");
			  var dlg = document.getElementById("dlgbox");
			  whitebg.style.display="block";
			  dlg.style.display="block";
			  
			  var winWidth = window.innerWidth;
			  var winWidth = window.innerHeight;
			  
			  dlg.style.left = (winWidth/2) - 0/2 + "px";
			  dlg.style.top = "250px";
			  
			  }
	 
	    </script>
                     
                   </body>
                
				   </html>
				   
				   
				   
				   <script type="text/javascript">
                           
                            $(".result").click(function(event) {
							
							event.preventDefault();
							
                           
                          $.post( $(this).attr("href"), $(this).serialize(), function(info){                  
                                $("#dlg-body").html(info);
                                  });
                        });
                    
                     </script>
