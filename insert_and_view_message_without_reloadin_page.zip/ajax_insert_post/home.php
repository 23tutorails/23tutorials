 
 
 
  <?php

              session_start();
               include("connection.php"); // connect to the database
               
     
              ?>
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  <style>
	 
	 
	   #search_text{
	   position:absolute;
	   width:400px;
	   height:30px;
	   }
	   
	   
	   #search{
	   position:absolute;
	   width:100px;
	   height:40px;
	   top:90px;
	   left:411px;
	   }
</style>	   

        <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
     
	 
	   <script type="text/javascript">
             $(document).ready(function(){
	            var form = $('#form');
	             var submit = $('#search');

	              form.on('submit', function(e) {
		         // prevent default action
		            e.preventDefault();
		            // send ajax request
		              $.ajax({
			        url: 'insert.php',
			        type: 'POST',
			        cache: false,
			         data: form.serialize(), //form serizlize data
			          beforeSend: function(){
				        // change submit button value text and disabled it
				      submit.val('Submitting...').attr('disabled', 'disabled');
			         },
			
				success: function(data){
                 
				 
				 
				// reset form and button
				form.trigger('reset');
				submit.val('submit').removeAttr('disabled');
			},
			error: function(e){
				alert(e);
			 }
		  });
	    });
     });

     </script>
	 
     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> Easygoing tutorial</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				   
						 
				 <div id="register_div">

                  <p>Insert and select from the database without refreshing or reloading the page.  </p>  <br><br>
               
			      
				  <form  method="post" id="form" >
                      <input type="text" name="name" id="search_text">
  
                          <input type="submit"  id="search" value="Submit">
  
                  </form>
					  
					  
					  <div id="preview"style="position:absolute; top:140px;">
					  
  
                          <script type="text/javascript">
                              $(document).ready(function(){
	                          setInterval(function(){
	                         $('#preview').load('select.php')
	                                }, 1000);
	                              });
  
   
                            </script>  
                    
					  
					  </div>
					 
                   </body>
                
				   </html>

				   
				   