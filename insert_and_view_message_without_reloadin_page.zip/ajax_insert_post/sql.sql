-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2016 at 02:52 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `script`
--
CREATE DATABASE IF NOT EXISTS `script` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `script`;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `mail` varchar(128) NOT NULL,
  `comment` text NOT NULL,
  `post_id` int(8) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=225 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `name`, `mail`, `comment`, `post_id`, `date`) VALUES
(217, 'Fdfdff', '', '', 0, '2016-04-05 02:08:09'),
(218, 'Ndicho Albert', '', '', 0, '2016-04-05 02:11:12'),
(219, 'John Gool', '', '', 0, '2016-04-05 02:14:23'),
(220, 'Kool Giu', '', '', 0, '2016-04-05 02:15:35'),
(221, 'Hhhhhh', '', '', 0, '2016-04-05 02:35:12'),
(222, 'Jooood Nuo', '', '', 0, '2016-04-05 02:38:12'),
(223, 'Yyu', '', '', 0, '2016-04-05 02:39:21'),
(224, 'Better ', '', '', 0, '2016-04-19 00:55:44');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--


