<?php
include('connection.php');


$names=$_POST['name'];
$cap=ucwords($names);

  
mysql_query("insert into comment(name) values ('$cap')");




?>
