<?php
include("connection.php"); // Includes the file connect.php to connect to database
 

$result = mysql_query("SELECT * FROM `comment` ");
while($row = mysql_fetch_array($result))

echo"<div id='result'>". $row['name'] ."</div>";
?>  
  