   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="js/register_form_validation.js"></script>
	    
		 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">Easygoing tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  
				 
				 <div id="register_div">

                <h1>Register below</h1>
               <form name="myForm" action="exec.php" onsubmit="return(validate());" method="post">
    
                <br>
                     <input type="text" name="firstname" placeholder="FIRST NAME" class="reg"><br>
                <br>
                <br>
                     <input type="text" name="secondname" placeholder="SECOND NAME" class="reg"><br>
                <br>
                <br>
                     <input type="text" name="email" name="search" placeholder="EMAIL" class="reg" id="input_text"><br>
                <br>
    
                <br>
                 <td><input type="password" name="password" placeholder="PASSWORD" class="reg" id="password_text"><br>
                <br>
                 <br>
               
			        <input type="password" name="retype" placeholder="RE-TYPE PASSWOED" class="reg" id="retypepass_text"><br><br>

                      Male<input type="radio" name="sex" value="male">
    
                      Female<input type="radio" name="sex" value="female"><br><br>
               
			   <font color="green">Born on</font><br>
                     Day<select name="day">
                     <option>1</option>
                     <option>2</option>
                     <option>3</option>
                     <option>4</option>
                     <option>5</option>
                     <option>6</option>
                     <option>7</option>
                     <option>8</option>
                     <option>9</option>
                     <option>10</option>
                     <option>11</option>
                     <option>12</option>
                     <option>13</option>
                     <option>14</option>
                     <option>15</option>
                     <option>16</option>
                     <option>17</option>
                     <option>18</option>
                     <option>19</option>
                     <option>20</option>
                     <option>21</option>
                     <option>22</option>
                     <option>23</option>
                     <option>24</option>
                     <option>25</option>
                     <option>26</option>
                     <option>27</option>
                     <option>28</option>
                     <option>29</option>
                     <option>30</option>
                     <option>31</option>
   
                     </select>
   
                 Month<select name="month">
                     <option>January</option>
                     <option>February</option>
                     <option>March</option>
                     <option>April</option>
                     <option>May</option>
                     <option>June</option>
                     <option>July</option>
                     <option>August</option>
                     <option>September</option>
                     <option>October</option>
                     <option>November</option>
                     <option>December</option>
                    
					 </select>
   
                 Year<select name="year" >
   
                     <option>1924</option>
                     <option>1923</option>
                     <option>1922</option>
                     <option>1921</option>
                     <option>1920</option>
                     <option>1919</option>
                     <option>1918</option>
                     <option>1917</option>
                     <option>1916</option>
                     <option>1915</option>
                     <option>1914</option>
                     <option>1913</option>
                     <option>1912</option>
                     <option>1911</option>
                     <option>1910</option>
                     </select><br/><br>
  
                     <br>
    
                   <input type="hidden" name="profile_picture" value="p.jpg">
                   <td><input name="submit" type="submit" value="Submit" id="sum"/></td>
    
	               </form>
  
                   <br>
                   <div id="preview"  style="width:180px; border:0px solid black; position:absolute; top:243px; left:305px;">
				   
				   </div>
	              
	
                 </div>	
	             
               </body>
                
	      </html>
		  
		  
		  


     <script type="text/javascript">
    $(function(){

     $('#retypepass_text').keyup(function(){
	     
		 var password = $('#password_text').val();
		 
		  var retype_password = $('#retypepass_text').val();
		 
		   if(retype_password==password)
		   {
		      
			   $('#preview').html("<span style='color:red;'>The password matches!</span>&nbsp;" )
		   
		   }else
		   
		   {
		   
		    $('#preview').html("<span style='color:green;'>The password does not matched</span>&nbsp;" )
		   
		   }
		   
		 
	   }); 
	});	

</script>


  <script type="text/javascript">

    $(function(){

     $('#password_text').keyup(function(){
	     
		 var password = $('#password_text').val();
		 
		   if(password.length <6)
		   {
		      
			   $('#preview').html("<span style='color:red;'>Password too short or weak!</span>&nbsp;" )
		   
		   }else
		   
		   {
		   
		    $('#preview').html("<span style='color:green;'>Password strong, that ok.</span>&nbsp;" )
		   
		   }
		   
		 
	   }); 
	});	

</script>
		  
		  
		  
		  
		