 
 
 
  
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  <style>
	 
	 
	   #search_text{
	   position:absolute;
	   width:400px;
	   height:30px;
	   }
	   
	   
	   #search{
	   position:absolute;
	   width:100px;
	   height:40px;
	   top:90px;
	   left:411px;
	   }
</style>	   

        <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
     
     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> Easygoing tutorial</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				   
						 
				 <div id="register_div">

               <p>Convert all first letter of a word into capital letters in the database in php  </p>  <br><br>
               
			      
				  <form  method="post" id="form" action="insert.php">
                      <input type="text" name="name" id="search_text">
  
                          <input type="submit"  id="search" value="Submit">
  
                  </form>
					  
					  
					  <div style="position:absolute; top:140px;">
					  
					      <?php
                           include("connection.php");
                                $result = mysql_query("SELECT * FROM `comment` ");
                               while($row = mysql_fetch_array($result))

                              echo"<div id='result'>". $row['name'] ."</div>";
                              ?> 
					  
					  </div>
					 
                   </body>
                
				   </html>

				   
				   