 
 
 
  <?php

              session_start();
               include("connection.php"); // connect to the database
                include("function.php");
     
              ?>
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	   
	   
	   
	   <!-- Below is the external css for styling the posting div-->
      <link rel="stylesheet" type="text/css" href="css/account.css"/>
	  <style>
	 
      </style>	   

        <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
     
	 
	  
     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> Easygoing tutorial</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				   
						 
				 <div id="register_div">

                  <p>Twitter like edit account system with</p>  <br><br>
               
			      <div id="account_content_div">
						   
						   <p id="account_header_text">Account</p>
						   
						   <p id="account_text">Change your basic account and language settings</p>
						  <hr id="horizontal_line1">
						  
						  <?php
						  
						  $member_id=$_SESSION["logged"];
						  
						  $query=mysql_query("SELECT * FROM member WHERE member_id='$member_id' ");
						  while($row=mysql_fetch_array($query)){
						  
						  echo'
						  
						  <form name="myForm" action="edit_account.php" onsubmit="return(validate());" method="POST" id="position_edit_form">
						  
						  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  First Name  
                            &nbsp;&nbsp;<input type="text" name="firstname" size="49" style="height:30;" value="'.$row['firstname'].'" class="edit_account_form"><br>
                                <br>
                           &nbsp; Second Name
                           
						   &nbsp;&nbsp;<input type="text" name="secondname" size="49" style="height:30;" value="'.$row['secondname'].'" class="edit_account_form"><br>
							<br>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  Email
						   
						   &nbsp;&nbsp;<input type="text" name="email" size="49" style="height:30;" value="'.$row['email'].'" class="edit_account_form"><br>
                           <br>
    
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  Password
                          &nbsp;&nbsp;<input type="password" name="password" size="49" style="height:30;" value="'.$row['password'].'" class="edit_account_form"><br>
                           <br>
                           
						   <input name="submit" type="submit" value="Submit" name="submit_button" id="submit_button"/>
						   </form>
						   
                            ';
						  
						  }
						  
						  ?>
						  

						  </div>
				      
					   
					 
                   </body>
                
				   </html>

				   
				   