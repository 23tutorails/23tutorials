<?php

          session_start();
          include("connection.php");
          include("function.php");
  
  
         $my_id= $_SESSION["logged"];
			 
                  $firstname=$_POST['firstname'];
				  $secondname=$_POST['secondname'];
				  $email=$_POST['email'];
				  $password=$_POST['password'];
                 
				 $query = mysql_query("SELECT * FROM member WHERE `email`='$email' AND member_id!='$my_id' ");
                 
				 if(mysql_num_rows($query) > 0)
				 
				     {
                      
					  echo"
                           <script type=\"text/javascript\">
							
							alert(\"Please this email address already existed / try another email\");
							 
							 window.location='home.php';
						  
						  </script>

                            ";

                        }else
						
						{
				 
                   mysql_query("UPDATE member SET firstname='$firstname',secondname='$secondname', email='$email', password='$password' WHERE member_id='$my_id' ") or
                 
				   die(mysql_error());
				 
                    {
	             	  echo "<script type=\"text/javascript\">
							
							alert(\"Your account has been edited\");
							
							window.location='home.php';
							
						</script>";
			        }
                 
				  }
          ?>