

    <?php
    
	//below variables are being assign to names of input fields in the registration form.
	session_start();
    include('connection.php');
    $firstname=$_POST['firstname'];
    $secondname=$_POST['secondname'];
    $email=$_POST['email'];
    
    $password=$_POST['password'];
	
	
	//Below insert the registered user information into the database when it has passed the above validation.
	 
    mysql_query("INSERT INTO member(firstname, secondname, email, sex, password)
	VALUES('$firstname', '$secondname', '$email', '$password')");
    {
                      
					  echo"
                           <script type=\"text/javascript\">
							
							alert(\"login in now with these email ($email) and password ($password) to edit your account\");
							 
							 window.location='index.php';
						  
						  </script>

                            ";

                        }
	
	
    
	?>
	
	
     