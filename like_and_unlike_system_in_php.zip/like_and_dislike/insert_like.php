
        <?php

           
             include("connection.php");
            
      
	     ?>




         <?php
         
				$post_id=$_GET['post_id'];

                mysql_query("INSERT INTO likes(post_number) VALUES('$post_id') ") or
                die(mysql_error());
				{
					
		                    echo "<script type=\"text/javascript\">
						          	alert(\"like added\");
							         window.location='index.php';
						          </script>";
			    }
          
		  ?>
		  
		 