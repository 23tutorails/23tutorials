
       <?php

           
            include("connection.php");
            
  
       ?>




        <?php
             
			    // below insert the dislike into the database.
			  
               
                $post_id=$_GET['post_id'];

                mysql_query("INSERT INTO dislike(post_number) VALUES('$post_id') ") or
                die(mysql_error());
				{
					
		                    echo "<script type=\"text/javascript\">
						          	alert(\"Dislike added\");
							         window.location='index.php';
						          </script>";
			   }
          
		  ?>
		  
		  