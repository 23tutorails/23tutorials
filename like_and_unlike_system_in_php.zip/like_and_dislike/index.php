   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="js/register_form_validation.js"></script>
	    
		 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">Easygoing tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  
				  <div style="position:relative; top:220px;">
							   <?php
                                       include("connection.php");
									   
                                      $result = mysql_query("SELECT * FROM `post` ");
                                         while($row = mysql_fetch_array($result))
										 
										 {
										      $id=$row["post_id"];
										 
										 $view= mysql_query("SELECT * FROM likes WHERE post_number = '$id'")or die(mysql_error());
											$counter = 0;
											WHILE($stat = mysql_fetch_array($view)){
											$counter++;
										}
										$allview = $counter;
											  
											
										$dislike_view= mysql_query("SELECT * FROM dislike WHERE post_number = '$id'")or die(mysql_error());
											$counter = 0;
											WHILE($stat = mysql_fetch_array($dislike_view)){
											$counter++;
										}
										$dislikeview = $counter;	
											  
											  
										 echo"<div class='post_Container'>";
										 
										  echo"<div class='sub_Container'>";
										 
                                         
										 echo"". $row['commenttext'] ."<br>";
										  
										 
										 echo"</div>";
										 
										 echo'<a href="insert_like.php?post_id='.$row['post_id'].'" class="styling_post_like_link" >like</a>';
										 
										 echo"<p class='styling_like_count' >$allview </span></p>";
										 
										 
										  echo'<a href="insert_dlike.php?post_id='.$row['post_id'].'" class="styling_unlike_button" >Dislike</a>';
										 
										  echo"<p class='styling_unlike_count'>$dislikeview</span></p>";
										 
										  echo"</div><br>";
										 
										 
										   }
										 

							    ?>  
  
							</div>
				  
				 
				 <div id="post_div">
					
                         <form action="exec.php" METHOD="POST" onsubmit="return(validate())" name="post_comment">
					
				          <div class="UIComposer_Box">
                          <textarea class="watermark" class="input"  placeholder=" &nbsp;&nbsp;What is on your mind." name="post_text" ></textarea>


                           </div>
					       <input type="submit" name="submit_post" value="Tweet"  class="post_button">
						   
						  
						   <div  class="count_div"></div>
						   
						   
				            </form>	
							
							</div>	
						
	             
               </body>
                
	      </html>
		  
		  