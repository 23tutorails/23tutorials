   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	   <!-- Below is the external css for styling the modal box-->
      <link rel="stylesheet" type="text/css" href="css/modal_box.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="js/register_form_validation.js"></script>
	    
		 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">Easygoing tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  
				  <div style="position:relative; top:220px;">
							   <?php
                                       include("connection.php");
									   
                                      $result = mysql_query("SELECT * FROM `post` ");
                                         while($row = mysql_fetch_array($result))
										 
										 {
										      $id=$row["post_id"];
										 
											  
											  
										 echo"<div class='post_Container'>";
										 
										  echo"<div class='sub_Container'>";
										 
                                         
										 echo"". $row['commenttext'] ."<br>";
										  
										 
										 echo"</div>";
										 
										 echo'<a href="search.php?send='.$row['post_id'].'" class="link1"><div id="button_style1" onclick="showDialog()">click here to get the id of this post</div></a>';
										 
										  echo"</div><br>";
										 
										 
										   }
							
							    ?>  
  
							</div>
				  
				 
				 <div id="post_div">
					
                         <form action="exec.php" METHOD="POST" onsubmit="return(validate())" name="post_comment">
					
				          <div class="UIComposer_Box">
                          <textarea class="watermark" class="input"  placeholder=" &nbsp;&nbsp;What is on your mind." name="post_text" ></textarea>


                           </div>
					       <input type="submit" name="submit_post" value="Tweet"  class="post_button">
						   
						  
						   <div  class="count_div"></div>
						   
						   
				            </form>	
							
							</div>	
						
						   
						
		<div id="white-background">
	        </div>		    
	 
	     <div id="dlgbox">
	    <div id="dlg-header">This is the id of the post you just click in a modal box.</div>
		<div id="dlg-body"> </div>
	    <div id="dlg-footer">
            <button onclick="dlglogin()">backn</button>
          </div>
		  </div>
	             
               </body>
                
	      </html>
	



      <script>
	   function dlglogin(){
	          var whitebg = document.getElementById("white-background");
			  var dlg = document.getElementById("dlgbox");
			  whitebg.style.display="none";
			  dlg.style.display="none";
			  
			  }
			  
			  function showDialog(){
			  var whitebg = document.getElementById("white-background");
			  var dlg = document.getElementById("dlgbox");
			  whitebg.style.display="block";
			  dlg.style.display="block";
			  
			  var winWidth = window.innerWidth;
			  var winWidth = window.innerHeight;
			  
			  dlg.style.left = (winWidth/2) - 480/2 + "px";
			  dlg.style.top = "250px";
			  
			  }
	 
	 </script>













	
		   <script>
	        $(document).ready(function(){
		
		   $('.watermark').on('keyup', function(){
			var username = $('.watermark').val();
			if (username.length >140) {
			
			jQuery(".post_button").attr('disabled', 'disabled'); 
			
			} else {
			   
			   jQuery(".post_button").removeAttr('disabled');
			   
			 }
			
			
		
		//count number of string
		  var text =$('.watermark').val();
		  
		  var maximun_text=140;
		  
		  var text_number = text.length;
		  
		  var count_text= maximun_text-text_number;
		  
		  		  
		  $('.count_div').html(count_text);
		
		
		});
		
	});
	</script>
	
	 <script>
	       $(document).ready(function(){
		
			var username = $('.watermark').val();
			if (document.location.reload) {
			
			jQuery(".post_button").attr('disabled', 'disabled'); 

			
			} 
		});
	
	</script>

	
	<script type="text/javascript">
                           
                            $(".link1").click(function(event) {
							
							event.preventDefault();
							
                           
                          $.post( $(this).attr("href"), $(this).serialize(), function(info){                  
                                $("#dlg-body").html(info);
                                  });
                        });
                    
                     </script>