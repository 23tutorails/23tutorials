   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	      <script type="text/javascript" src="js/validate_result.js"></script>
	   
     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="color:white;">23tutorials.com tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
	             <p style="color:red; position:absolute; top:30px; left:120px; font-size:40px;">How to set and mark exam and get scores in php and Javascript</p>
				 
				 <div class="exam-div">
				 
				 <form  method="POST" onsubmit="return(validate());" name="myForm">
				 
				 <!--section for question 1 and answers -->
				 <p style="position:absolute; top:-10px; left:10px; font-size:19px;">1) How many continets are there in the world.</p>
				 
				 <select name="question_1" style="position:absolute; top:40px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> 4 Continents</option>
				   
				   <option> 5 Continents</option>
				   
				   <option> 6 Continents</option>
				   
				   <option> 3 Continents</option>
				 
				 </select> <p id="question_1" style="position:absolute; top:20px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 				 <!--section for question 2 and answers -->
				 
				 <p style="position:absolute; top:70px; left:10px; font-size:19px;">2) Who is the first black president in U.S.A  </p>
				 
				 <select name="question_2" style="position:absolute; top:120px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> George Bush</option>
				   
				   <option> Barack Obama</option>
				   
				   <option> Donald Trump</option>
				   
				   <option> Bill clinton</option>
				 
				 </select> <p id="question_2" style="position:absolute; top:100px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 
				 
				 <p style="position:absolute; top:150px; left:10px; font-size:19px;">3) Cairo is the capital of which of the following countries  </p>
				 
				 <select name="question_3" style="position:absolute; top:200px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> Egypt</option>
				   
				   <option> Syria</option>
				   
				   <option> Lybia</option>
				   
				   <option> Morroca</option>
				 
				 </select> <p id="question_3" style="position:absolute; top:182px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 
				 <p style="position:absolute; top:220px; left:10px; font-size:19px;">4) Kangaru is an animal found in;  </p>
				 
				 <select name="question_4" style="position:absolute; top:270px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> U.S.A</option>
				   
				   <option> France</option>
				   
				   <option> Australia</option>
				   
				   <option> South Africa</option>
				 
				 </select> <p id="question_4" style="position:absolute; top:252px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 <p style="position:absolute; top:300px; left:10px; font-size:19px;">5) F.C. Barcelona is a football club in;  </p>
				 
				 <select name="question_5" style="position:absolute; top:350px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> England</option>
				   
				   <option> Spain</option>
				   
				   <option> Russia</option>
				   
				   <option> Germany</option>
				 
				 </select>  <p id="question_5" style="position:absolute; top:332px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 
				 <p style="position:absolute; top:380px; left:10px; font-size:19px;">6) Which of the following animals is a domestic animal.  </p>
				 
				 <select name="question_6" style="position:absolute; top:430px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> Lion</option>
				   
				   <option> Elephant</option>
				   
				   <option> Shark</option>
				   
				   <option> Cat</option>
				 
				 </select>  <p id="question_6" style="position:absolute; top:412px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 
				 <p style="position:absolute; top:460px; left:10px; font-size:19px;">7) which of the following countries is the most populated in the world.  </p>
				 
				 <select name="question_7" style="position:absolute; top:510px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> Japan</option>
				   
				   <option> France</option>
				   
				   <option> Egypt</option>
				   
				   <option> China</option>
				 
				 </select>   <p id="question_7" style="position:absolute; top:492px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 <p style="position:absolute; top:540px; left:10px; font-size:19px;">8) The Holy Bible book is been used by.</p>
				 
				 <select name="question_8" style="position:absolute; top:590px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> Budist</option>
				   
				   <option> Islamist</option>
				   
				   <option> None</option>
				   
				   <option> Christian</option>
				 
				 </select> <p id="question_8" style="position:absolute; top:572px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 <p style="position:absolute; top:620px; left:10px; font-size:19px;">9) The official language in France is.) </p>
				 
				 <select name="question_9" style="position:absolute; top:670px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> French</option>
				   
				   <option> English</option>
				   
				   <option> Spanish</option>
				   
				   <option> Chinese</option>
				 
				 </select>  <p id="question_9" style="position:absolute; top:652px; left:340px; width:300px; color:green; font-size:20px;"> </p>
				 
				 <p style="position:absolute; top:700px; left:10px; font-size:19px;">10) How many states does the U.S.A has.) </p>
				 
				 <select name="question_10" style="position:absolute; top:750px; left:30px; width:300px; color:blue; font-size:20px;"> 
				 
				   <option> 56</option>
				   
				   <option> 35</option>
				   
				   <option> 11</option>
				   
				   <option> 50</option>
				 
				 </select> <p  id="question_10" style="position:absolute; top:732px; left:340px; width:300px; color:green; font-size:20px;"></p>
				 
				 
				 <input type="submit" name="" value="Result" class="submit-button">
				 
				 </form>
				 
				 </div>
				 
				 
               </body>
                
	      </html>
		  