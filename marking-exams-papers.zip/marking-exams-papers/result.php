

    <?php
    
       $value1 = $_POST['question_1'];
	   
	   $value2 = $_POST['question_2'];
	   
	   $value3 = $_POST['question_3'];
	   
	   $value4 = $_POST['question_4'];
	   
	   $value5 = $_POST['question_5'];
	   
	   $value6 = $_POST['question_6'];
	   
	   $value7 = $_POST['question_7'];
	   
	   $value8 = $_POST['question_8'];
	   
	   $value9 = $_POST['question_9'];
	   
	   $value10 = $_POST['question_10'];
	   
	  
	
	    if( $value1 == '6 Continents' OR  $value2== 'Barack Obama' OR  $value3=='Egypt' OR  $value4=='Australia' OR  $value5=='Spain')
	
	   {
		
        echo"<script type=\"text/javascript\">
			alert(\"correct\");
			window.location='index.php';
			</script>";
			
		
	    }else{
		
		 echo"<script type=\"text/javascript\">
			alert(\"not corrects\");
			window.location='index.php';
			</script>";
		
		}
	?>