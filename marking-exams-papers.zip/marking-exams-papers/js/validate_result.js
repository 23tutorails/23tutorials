
   
   function validate()
   {
   
  
   
   var question_1 = document.myForm.question_1.value;
   
   if(question_1 =='6 Continents')
   {
   document.getElementById("question_1").innerHTML="<font color=red>Correct</font>";
   
   }
     else
   
     {
      
	  document.getElementById("question_1").innerHTML="<font color=red>Wrong</font>";
      
   
     }
   
   
    var question_2 =document.myForm.question_2.value;
   
   if(question_2 =="Barack Obama")
   {
   document.getElementById("question_2").innerHTML="<font color=red>Correct</font>";
   
   }
   
   else
   
   {
   
   document.getElementById("question_2").innerHTML="<font color=red>Wrong</font>";
  
   }
  
  
  var question_3 =document.myForm.question_3.value;
  if(question_3 =="Egypt")
    {
	document.getElementById("question_3").innerHTML="<font color=red>Correct</font>";
	
	}else
	
	{
	
	document.getElementById("question_3").innerHTML="<font color=red>Wrong</font>";
	
	}
	
	
	var  question_4 =document.myForm.question_4.value;
	if(question_4 =="Australia")
	 {
	 document.getElementById("question_4").innerHTML="<font color=red>Correct</font>";
	
	 }else
	 
	 {
	 
	   document.getElementById("question_4").innerHTML="<font color=red>Wrong</font>";
	  
	 }
	 
	 
	 
	 var question_5=document.myForm.question_5.value;
	if(question_5=="Spain")
	 {
	 document.getElementById("question_5").innerHTML="<font color=red>Correct</font>";
	 
	 
	 }else{
	 
	 document.getElementById("question_5").innerHTML="<font color=red>Wrong</font>";
	 
	 
	 }
	 
	 
	 var question_6 =document.myForm.question_6.value;
	  if(question_6=="Cat")
	 {
	 document.getElementById("question_6").innerHTML="<font color=red>Correct</font>";
	
	 
	 }else{
	 
	 document.getElementById("question_6").innerHTML="<font color=red>Wrong</font>";
	
	 
	 }
	 
	 
	 
	 
	 var question_7=document.myForm.question_7.value;
	if(question_7 =="China")
	 {
	 document.getElementById("question_7").innerHTML="<font color=red>Correct</font>";
	
	 
	 }else{
	 
         document.getElementById("question_7").innerHTML="<font color=red>Wrong</font>";
	     
	 }
	 
	 
	 var question_8 =document.myForm.question_8.value;
	  if( question_8=="Christian")
	 {
	 document.getElementById("question_8").innerHTML="<font color=red>Correct</font>";
	 
	 
	 }else{
	 
	   document.getElementById("question_8").innerHTML="<font color=red>Wrong</font>";
	     
	 }
	 
	 
	 var question_9=document.myForm.question_9.value;
	if( question_9=="French")
	 {
	 document.getElementById("question_9").innerHTML="<font color=red>Correct</font>";
	
	 
	 }else{
	 
	     document.getElementById("question_9").innerHTML="<font color=red>Wrong</font>";
	
	 }
	 
	 
	 var question_10=document.myForm.question_10.value;
	if( question_10=="50")
	 {
	   document.getElementById("question_10").innerHTML="<font color=red>Correct</font>";
	
	 
	  }else{
	 
	       document.getElementById("question_10").innerHTML="<font color=red>Wrong</font>";
	        
	    }
		

	 
	  return false;
	  } 
	