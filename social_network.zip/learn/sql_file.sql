-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2015 at 11:42 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `learn`
--
CREATE DATABASE IF NOT EXISTS `learn` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `learn`;

-- --------------------------------------------------------

--
-- Table structure for table `dislike`
--

CREATE TABLE IF NOT EXISTS `dislike` (
  `bookmark_id` int(11) NOT NULL AUTO_INCREMENT,
  `fan_id` int(11) NOT NULL,
  `post_number` int(11) NOT NULL,
  PRIMARY KEY (`bookmark_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `dislike`
--

INSERT INTO `dislike` (`bookmark_id`, `fan_id`, `post_number`) VALUES
(42, 3, 19),
(46, 3, 18),
(45, 3, 19),
(47, 3, 11),
(48, 3, 20),
(49, 3, 28),
(50, 3, 31);

-- --------------------------------------------------------

--
-- Table structure for table `friendship`
--

CREATE TABLE IF NOT EXISTS `friendship` (
  `friend_id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver` varchar(30) NOT NULL,
  `sender` varchar(30) NOT NULL,
  PRIMARY KEY (`friend_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `secondname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `profile_picture` varchar(30) NOT NULL,
  `day` varchar(100) NOT NULL,
  `month` varchar(30) NOT NULL,
  `year` varchar(100) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `firstname`, `secondname`, `email`, `sex`, `password`, `profile_picture`, `day`, `month`, `year`) VALUES
(3, 'lano', 'demi', 'lano@gmail.com', 'male', 'mmmm', '1448579743.jpg', '2', '12', '1991'),
(9, 'derick', 'demi', 'drick@gmail.com', 'male', 'MMMM', '1443347382laxy.jpg', '1', '11', '1999'),
(22, 'melo', 'samel', 'melo@gmail.com', '', 'mmmm', 'p.jpg', '0', '12', '1989'),
(24, 'fred', 'loon', 'fred@gmail.com', 'male', 'mmmm', 'p.jpg', '1', 'January', '2000'),
(19, 'kono', 'ssx', 'sxsx', '', 'xx', 'p.jpg', '1', 'January', '1995');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` varchar(5000) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageid`, `sender_id`, `receiver_id`, `message`, `date`) VALUES
(169, 19, 3, 'THANK GOD', '2015-10-26'),
(170, 19, 3, 'God is great', '2015-10-27'),
(173, 3, 19, 'God knows best', '2015-10-27'),
(174, 19, 3, 'God is great again', '2015-10-28'),
(175, 3, 22, 'God love you albert', '2015-11-21'),
(176, 19, 9, 'do you know that GOD is great', '2015-11-22'),
(181, 3, 9, 'God loves you albert', '2015-12-13');

-- --------------------------------------------------------

--
-- Table structure for table `myfriends`
--

CREATE TABLE IF NOT EXISTS `myfriends` (
  `friend_id` int(11) NOT NULL AUTO_INCREMENT,
  `myid` varchar(30) NOT NULL,
  `myfriends` varchar(30) NOT NULL,
  PRIMARY KEY (`friend_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `myfriends`
--

INSERT INTO `myfriends` (`friend_id`, `myid`, `myfriends`) VALUES
(3, '3', '9');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `commenttext` varchar(30) NOT NULL,
  `photo_name` varchar(30) NOT NULL,
  `photo_text` varchar(30) NOT NULL,
  `me` varchar(30) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `commenttext`, `photo_name`, `me`, `date`) VALUES
(38, '', '1450702648.jpg', '3', '2015-12-21 00:57:28'),
(37, 'love date\r\n', '', '3', '2015-12-21 00:32:41'),
(36, 'love dat', '', '3', '2015-12-21 00:27:29');

-- --------------------------------------------------------

--
-- Table structure for table `postcomments`
--

CREATE TABLE IF NOT EXISTS `postcomments` (
  `postcommentid` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `memberid` int(11) NOT NULL,
  `date` date NOT NULL,
  `comment` varchar(5000) NOT NULL,
  PRIMARY KEY (`postcommentid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `postcomments`
--

INSERT INTO `postcomments` (`postcommentid`, `postid`, `memberid`, `date`, `comment`) VALUES
(63, 20, 3, '2015-12-01', 'God is awesome');

-- --------------------------------------------------------

--
-- Table structure for table `post_photo`
--

CREATE TABLE IF NOT EXISTS `post_photo` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_name` varchar(30) NOT NULL,
  `member_id` varchar(30) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `post_photo`
--

INSERT INTO `post_photo` (`post_id`, `photo_name`, `member_id`, `date`) VALUES
(20, '1448329186bus_Crew_SC.jpg', '3', '2015-11-23 13:39:46'),
(21, '1448330043ngland_Revolution.jp', '3', '2015-11-23 13:54:03'),
(22, '1448410246on_Dynamo.jpg', '3', '2015-11-24 12:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `view`
--

CREATE TABLE IF NOT EXISTS `view` (
  `bookmark_id` int(11) NOT NULL AUTO_INCREMENT,
  `fan_id` int(11) NOT NULL,
  `post_number` int(11) NOT NULL,
  PRIMARY KEY (`bookmark_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9;

--
-- Dumping data for table `view`
--

INSERT INTO `view` (`bookmark_id`, `fan_id`, `post_number`) VALUES
(42, 3, 19),
(43, 3, 19),
(44, 3, 19),
(45, 3, 19),
(46, 3, 19),
(47, 3, 19),
(48, 3, 18),
(49, 3, 18),
(50, 3, 18),
(51, 3, 18),
(52, 3, 18),
(53, 3, 18),
(54, 3, 18),
(55, 3, 18),
(56, 3, 18),
(57, 3, 18),
(58, 3, 18),
(59, 3, 18),
(60, 3, 18),
(61, 3, 18),
(62, 3, 18),
(63, 3, 18),
(64, 3, 18),
(65, 3, 18),
(66, 3, 18),
(67, 3, 18),
(68, 3, 18),
(69, 3, 18),
(70, 3, 18),
(71, 3, 11),
(72, 3, 11),
(73, 3, 11),
(74, 3, 11),
(75, 3, 0),
(76, 3, 19),
(77, 3, 19),
(78, 3, 19),
(79, 3, 17),
(80, 3, 11),
(81, 3, 16),
(82, 3, 19),
(83, 3, 19),
(84, 3, 19),
(85, 3, 19),
(86, 3, 19),
(87, 3, 19),
(88, 3, 19),
(89, 3, 19),
(90, 3, 21),
(91, 3, 25),
(92, 3, 27),
(93, 3, 28),
(94, 3, 28),
(95, 3, 27),
(96, 3, 31);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
