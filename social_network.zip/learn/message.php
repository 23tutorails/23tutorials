         

		 <?php
                     include("connection.php");
                  
				     require_once("function.php");

                     $sendcomment=$_POST["message"]; //variable assign for the message

                     $sender= $_POST["sender"];  // variable assign for the person sending the message
                     $receiver=$_POST['receiver']; // variable assign for the person receiving the message.
					 
					 
					 if($sendcomment=="")  // check if the text box is empty.
					 {
					 
		                    echo "<script type=\"text/javascript\">
						          	alert(\"message box empty\");
							         window.location='messages.php';
						          </script>";
			               }
						   
					else
					      {
						  
						  //  below insert the message into the database
                     $query=mysql_query("INSERT INTO messages(sender_id,date,receiver_id,message) VALUES('$sender',NOW(),'$receiver','$sendcomment') ") or
                     die(mysql_error());
					
					 
		                    echo "<script type=\"text/javascript\">
						          	alert(\"message send\");
							         window.location='messages.php';
						          </script>";
			               }
	        ?>
           