 
 
		 <?php
               include("function.php");
			   include("connection.php");
						
		?>
						
						 <!-- Below count the numbers of friends you have-->
		     <?php
						    
							 $member_id=$_SESSION["logged"];							
								  $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$member_id' OR myfriends = '$member_id' ")or die(mysql_error());
								   $counter = 0;

							  	  while($row = mysql_fetch_array($post)){
				                  $counter++;
								 
									
								}
								
								$allview = $counter;
					  
					      echo"<p style='font-size:15px; position:absolute; margin:91px 0px 0px 358px;color:red;'> &nbsp;($allview)</p>";
							
					     ?>
						 
						
						 
						 <?php
				  
				                //Section for numbers of friendship requests
				  
				                 $member_id=$_SESSION["logged"];
                                 $query = mysql_query("SELECT * FROM friendship WHERE receiver = '$member_id'");
                                 
								  $counter = 0;
								 
								 
                                 while($row = mysql_fetch_array($query)) 
								 
								 { 
								 $counter++;
								 
	                             }
							    $allvieww = $counter; 
							   
                              echo"<p style='font-size:15px; position:absolute; margin:91px 0px 0px 560px;color:red;'> &nbsp;($allvieww)</p>";
					     
     						 ?>
						 
	