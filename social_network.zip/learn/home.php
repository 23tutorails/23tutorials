
              <?php

              session_start();
               include("connection.php"); // connect to the database
                include("function.php"); //get the id (member_id) for the login user
               include("insert.php"); //insert the add comment, text to the database
 
              ?>
  
   
       <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
         <html xmlns="http://www.w3.org/1999/xhtml">
         <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

          <!-- Below is the external css for styling the index page -->
		  <link rel="stylesheet" type="text/css" href="css/index.css"/>
          
		  
		  <!-- Below is the external css for styling the home page -->
		  <link rel="stylesheet" type="text/css" href="css/home.css"/>
          
		  
		  <!-- Below is the external css for styling the post text div or box-->
		  <link rel="stylesheet" type="text/css" href="css/comment_div.css"/>
	 
	      
		   <!-- Below is the external add post text validation in JavaScript -->
            <script type="text/javascript" src="js/add_post_js_validation.js"></script>
			 
			 
			  <!-- Below is the external link for live search engine. -->
			 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
                 <script type="text/javascript">
               $(function(){
               $(".search").keyup(function() 
               { 
               var searchid = $(this).val();
               var dataString = 'search='+ searchid;
               if(searchid!='')
               {
	            $.ajax({
	            type: "POST",
	            url: "search.php",
	             data: dataString,
	             cache: false,
	             success: function(html)
	             {
	               $("#result").html(html).show();
	            }
              });
                }return false;    
                 });

                 jQuery("#result").live("click",function(e){ 
	             var $clicked = $(e.target);
	             var $name = $clicked.find('.name').html();
	             var decoded = $("<div/>").html($name).text();
	             $('#searchid').val(decoded);
                 });
                 jQuery(document).live("click", function(e) { 
	             var $clicked = $(e.target);
	             if (! $clicked.hasClass("search")){
	             jQuery("#result").fadeOut(); 
                 	}
                 });
                 $('#searchid').click(function(){
	             jQuery("#result").fadeIn();
              });
            });
            </script>   

    </head>

         <body>
                  
				  <!--header--> 
                 <table id="header">
                      <tr>
                             <td id="header_text"> Easygoing</td>
                              
                      </tr>
                  </table>
				 <!--End of header--> 
				 
				         <?php
						 /* select the names of the login from the database*/
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$member_id' LIMIT 1");

                             echo "<table border='0px' id='profilename'>
                             ";

                             while($row = mysql_fetch_array($result))
                        {
                             echo "<tr>";
           
                             echo "<img src='uploads/".$row['profile_picture']."' class='profile_picture'>";
                             echo "<td>" . $row['firstname'] . "</td >";
                             echo "<td>". $row['secondname'] ."</td>";
                             echo "</tr>";
                        }
                             echo "</table>";


                       
                        
						?>           
						
						
				 <!--This is the div containing form for uploading pictures-->
	                   <div id="upload_picture">
					   
					   <form action="upload_photo.php" enctype="multipart/form-data" method="post" id="photo_upload_form" >
								
		               <input name="MAX_FILE_SIZE" type="hidden" value="1000000" > 
		               <input id="upload_file" name="file" type="file" ><br><br>
															
		               
		               <button name="savephoto" type="submit">Save Photo</button>
									
	                   </form>	
					   
					   </div>
				<!--End of the div containing form for uploading pictures-->
				
				<!--These are the links that links to other pages-->
					   <a href="logout.php"><button id="logout">Logout</button></a>
					   
					   <a href="friends.php"><button id="view_friend">View friends and friends request</button></a>
					   
					   <a href="messages.php"> <button class="message_link" id="position_link1" >view message</button></a>
					   
					   <a href="edit_account.php"> <button class="message_link" id="position_link" >Edit account</button></a>
					 
					 
					   
					  <p id="position_link3" >people you may know</p>
					   
					   
					   <!--This is the div for showing people you may know-->
					   <div id="people_you_know">
					   
					   <?php
					    
						/* people you may know script */
						
						$member_id=$_SESSION["logged"];
						
						/* below selecct from the database friend that you may know them */
						$result= mysql_query("select * FROM `member` WHERE `member_id`!='$member_id' LIMIT 4");
						while($row=mysql_fetch_array($result))
						  
						   {
						     $memberid = $row["member_id"];
									    
						    
							
							/* below check if the friend is already your friend */
							
							$member_id=$_SESSION["logged"];							
						    $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$member_id' AND myfriends='$memberid' OR myfriends = '$member_id' AND myid='$memberid'")or die(mysql_error());
								
							$num_rows  =mysql_numrows($post);
							
							if ($num_rows != 0 ){

							while($row = mysql_fetch_array($post)){
				
						    $myfriend = $memberid;
							$member_id=$_SESSION["logged"];
								
							if($myfriend == $member_id){
									
							$myfriend1 = $row['myfriends'];
							$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend1'")or die(mysql_error());
							$friendsa = mysql_fetch_array($friends);
							echo"";		  
							//echo" <div id='button_style'>Friends $memberid</div> ";
                            //echo'<hr class="line_1"> ';
									    
							}else{
										
							$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend'")or die(mysql_error());
							$friendsa = mysql_fetch_array($friends);
							
							/* If the person is your friend the div having this id button_style will be seen. */
							
							//echo" <div id='button_style'>Friends$memberid</div> ";
                             //echo'<hr class="line_1"> ';
									
							}
									
								}
								
								} else
							
							{
							
							/* else if the person is not your fiend the link below will appear.*/
						   
							echo'<div align="left"><img src="uploads/'.$row['profile_picture'].'" id="people_you_know_image" /></div>';
							echo'<div align="center"><a href="friendinfo.php?amifo='.$row["member_id"].'">'.$row['firstname']." ".$row['secondname'].'</a></div> ';	
							 echo'<a href="process.php?send='.$row['member_id'].'" ><div id="button_style1">Add Friend</div></a><br>';	
							echo'<hr class="line_1" "> ';
							echo'<br>';
								
						      }
							
							}
							
						?>   
					   
					   </div> 
					  
					   <!-- Div for posting text and photo on your time line timeline and friends-->
					   <div id="posting_div">
					   <!-- Form for sharing post-->
				          <form action="home.php" METHOD="POST" onsubmit="return(validate())" name="post_comment">
					
				          <div class="UIComposer_Box">
                          <textarea id="watermark" class="input"  placeholder="What is on your mind." name="commenttext" ></textarea>


                           </div>
					       <input type="submit" name="submit_post" value="Post" id="post_button">
				            </form> 
							<!--  End of Form for sharing post-->
							
							
							<!-- below is the form for uploading a photo that you will share-->
							<form action="share_photo.php" enctype="multipart/form-data" method="post" id="share_upload_photo" >
								
		                    <input name="MAX_FILE_SIZE" type="hidden" value="1000000"> 
		                    <input id="upload_file" name="file" type="file"><br>
														
		                    <button name="savephoto" type="submit" id="style_upload_button">Save Photo</button>
									
	                          </form>	
						       <!--End of Form for sharing photo-->
				         
                         
						 </div>
						
						
						
						<!-- Div that show posted texts, comment and photo of friends-->
					   
					       <div id="post_div" >
					   
				       <?php
                               /* select the post of your friends from the database*/
							   
                               $member_id=$_SESSION["logged"];
			                   $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$member_id' OR myfriends = '$member_id' ")or die(mysql_error());
								
			                   $num_rows  =mysql_numrows($post);
							
			                   if ($num_rows != 0 ){

		                       while($row = mysql_fetch_array($post)){
				
		                       $myfriend = $row['myid'];
			                   $myfriend1 = $row['myfriends'];
								
			                   if($myfriend == $member_id){
			
			                    
			                   }else{
			
			                   $myfriend1 = $member_id;
			                   }
                                  
                               $post=mysql_query("SELECT post.me, post.post_id, post.commenttext, post.photo_name
                               FROM post INNER JOIN member ON post.me = member.member_id WHERE post.me IN (SELECT myfriends FROM myfriends
                               INNER JOIN member
                               ON (myid = member.member_id)
   
                               WHERE myfriends = $myfriend OR myid='$member_id'

                               UNION

                               SELECT myid FROM myfriends INNER JOIN member ON (myfriends = member.member_id) WHERE myid = $myfriend1 OR myfriends = $member_id
  
                               UNION
  
                               SELECT me FROM post WHERE me = '$myfriend1' OR me=$myfriend ) 
                               ORDER BY post.date DESC");
    
	                             
	
	                            while($row = mysql_fetch_array($post)){
								$member=$row["me"];
								
								 $id=$row["post_id"];
								 
								 $post_text=$row["commenttext"];
								  
								 $photoname=$row["photo_name"];
								
							  $user=mysql_query("SELECT * FROM member WHERE member_id='$member'");
		                          $roww = mysql_fetch_array($user);
							   
							   /* select the number of like from the database*/
							   
							   $view= mysql_query("SELECT * FROM view WHERE post_number = '$id'")or die(mysql_error());
											$counter = 0;
											WHILE($stat = mysql_fetch_array($view)){
											$counter++;
										}
										$allview = $counter;
										
								/* select the number of Dislike from the database*/
							   
							   $dislike_view= mysql_query("SELECT * FROM dislike WHERE post_number = '$id'")or die(mysql_error());
											$counter = 0;
											WHILE($stat = mysql_fetch_array($dislike_view)){
											$counter++;
										}
										$dislikeview = $counter;

							   
							     /* div for posting and commenting*/
						         echo"<div id='comment_Container'>";
							   
							   
                                 /* div commenting*/
                                 echo'<div id="comment_body" >';
                            
				          	     /* area showing posting messages*/
					             
								 
					             echo'<img src="uploads/'.$roww['profile_picture'].'" id="post_user_photo" />';
					        	 echo'<p id="post_text_decoration" >
								 <a href="friendinfo.php?amifo='.$roww["member_id"].'">'.$roww["firstname"].'&nbsp;'.$roww["secondname"].'&nbsp;&nbsp;&nbsp;
					        	 </a></p>';
								 
								 if($post_text)  
								 
								 {
                                 echo'<p id="styling_post_text">'.$row["commenttext"].'</p>';
								 
								 /* placing the like and unlike results for a post text   */
								 echo"<p id='styling_like_review' >($allview) likes </span></p>";
								   
								 echo"<p id='styling_unlike_review' >($dislikeview)Dislikes </span></p>";
								 
								 /* placing the like and unlike links for a post text   */
								 echo'<a href="insert_like.php?post_id='.$row['post_id'].'" id="styling_like_button" >like</a>';
								 
								 echo'<a href="insert_dlike.php?post_id='.$row['post_id'].'" id="styling_unlike_button" >Dislike</a>';
								 
								 }
								 elseif($photoname)
								 {
						
								 
								 echo'<img src="share_upload/'.$row['photo_name'].'" id="styling_post_photo" />';
								 
								 /* placing the like and unlike results for a post picture */
								 
								 
								 
								 /* placing the like and unlike links for a post picture  */
								 echo'<a href="insert_like.php?post_id='.$row['post_id'].'" id="styling_post_like_link" >like</a>';
								 
								 echo'<a href="insert_dlike.php?post_id='.$row['post_id'].'" id="styling_post_unlike_link" >Dislike</a>';
								 
								 echo"<p id='styling_post_like_preview' >($allview) likes </span></p>";
								 echo"<p id='styling_post_unlike_preview' >($dislikeview) Dislikes </span></p>";
								 
								 }


                                  echo'</div>';
		
		                       /* end of div commenting*/
						 
						       $comment = mysql_query("SELECT * FROM postcomments WHERE postid='$id' ORDER BY date DESC");
                               while($rows = mysql_fetch_array($comment)){
						 
						       $commentid=$rows["memberid"];
							 
						      $postt=mysql_query("SELECT * FROM member WHERE member_id='$commentid'");
		                      $rowwd = mysql_fetch_array($postt);
					         
						  
						      /*  area showing comment that is related to each each post*/
                              echo'<img src="uploads/'.$rowwd['profile_picture'].'" id="user_comment_photo" />';
						      echo'<p id="user_comment_info">
							  <a href="friendinfo.php?amifo='.$rowwd["member_id"].'">'.$rowwd["firstname"].' '.$rowwd["secondname"].'</a></p>'; 
						      echo'<div id="comment_text" >'.$rows["comment"].'-'.$rows["date"].'.</span></div>';
						      echo'<hr>';
						  
				                                                  }  
																  
                             $myid=mysql_query("SELECT * FROM member WHERE member_id='$member_id'");
		                     $rowww = mysql_fetch_array($myid);
						  
						  /*  form for adding comment*/
						         echo'<form action="home.php" name="myForm" METHOD="POST" onsubmit="return validateForm()">';
						         echo'<img src="uploads/'.$rowww['profile_picture'].'" id="user_info" />';
                                 echo'<input type="text" name="comment" placeholder="Add comment" id="add_comment_field">';
						         echo'<input type="hidden" value=" '.$row['post_id'].'" name="postid">';
						         echo'<input type="submit" name="submit_comment" value="send" id="comment_button">';
						         echo'</form>'; 
							   
							     
							    echo"</div><br>";
							   
							  }
				    	   }
                        }	 
	
	                        
							
					  ?>	
                      
					   
					  
					   
					  </div>
					  
					  <!--search engine--> 
                 <div id="noticeboard">
                          <div class="content">
                          <input type="text" class="search" id="searchid" placeholder="Search for people" />
	                      &nbsp; &nbsp; Powered by Easygoing<br /> 
                       <div id="result">
                         </div>
                       </div>
					   
					   </div>  <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
					   
					   <?php
                               

                               $res = mysql_query("SELECT * FROM `member` WHERE status=1");
                             
							   if(mysql_num_rows($res) > 0){
                               
							   while($row = mysql_fetch_assoc($res)){  
                                 $array = $row['member_id'];  // this adds each online user id to the array         
                                 $name = $row['firstname'];
								 
                             echo "online";
							 
							  echo "$name";
                                  
								  }
                                    }
								  
                          ?>
					
					   
               </body>
               
			   </html>
