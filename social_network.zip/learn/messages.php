
  <?php

  session_start();
  include("connection.php");
  include("function.php");
  
  include("insert.php");

   
  ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

          <!-- Below is the external css for styling the index page -->
		  <link rel="stylesheet" type="text/css" href="css/index.css"/>
          
		  
		  <!-- Below is the external css for styling the home page -->
		  <link rel="stylesheet" type="text/css" href="css/home.css"/>
		  
		  <!-- Below is the external css for styling the messages page -->
         <link rel="stylesheet" type="text/css" href="css/message.css"/>
	 
	 
 
          <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
         
		 <script type="text/javascript">
             $(function(){
                $(".search").keyup(function() 
                  { 
                   var searchid = $(this).val();
                   var dataString = 'search='+ searchid;
                   if(searchid!='')
                 {
	               $.ajax({
	               type: "POST",
	               url: "search.php",
	               data: dataString,
	               cache: false,
	               success: function(html)
	             {
	               $("#result").html(html).show();
	             }
	             
				 });
                
				}return false;    
                
				});

                jQuery("#result").live("click",function(e){ 
	            var $clicked = $(e.target);
	            var $name = $clicked.find('.name').html();
	            var decoded = $("<div/>").html($name).text();
	            $('#searchid').val(decoded);
                });
                 jQuery(document).live("click", function(e) { 
	             var $clicked = $(e.target);
	             if (! $clicked.hasClass("search")){
	             jQuery("#result").fadeOut(); 
	            
				 }
                 });
                    $('#searchid').click(function(){
	                jQuery("#result").fadeIn();
                  });
                   });
            
			  </script>   

     </head>

         <body>

                 <table bgcolor="green" width="100%" height="80">
                      <tr>
                             <td id="header_text"> Easygoing</td>
                              
                      </tr>
                 </table>
				 
				     
				         <?php
						 /* select the names of the login from the database*/
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$member_id' LIMIT 1");

                             echo "<table border='0px' id='profilename'>
                             ";

                             while($row = mysql_fetch_array($result))
                        {
                             echo "<tr>";
           
                             echo "<img src='uploads/".$row['profile_picture']."'  width='170px' height='170px' class='profile_picture'>";
                             echo "<td>" . $row['firstname'] . "</td >";
                             echo "<td>". $row['secondname'] ."</td>";
                             echo "</tr>";
                        }
                             echo "</table>";


                       
                        
						?>           
				 
	                   
					    <a href="home.php"><button id="logout">Home</button></a>
					   
					   
					   <!--These are the links that links to other pages-->
					   <a href="logout.php"><button id="logout">Logout</button></a>
					   
					   <a href="friends.php"><button id="view_friend">View friends and friends request</button></a>
					   
					   <a href="messages.php"> <button class="message_link" id="position_link1" >view message</button></a>
					   
					   <a href="edit_account.php"> <button class="message_link" id="position_link" >Edit account</button></a>
					   
					   <p id="message_title"> Message you sent<?php
					   include("include_message.php");
					   ?>
					   </p>
					  
					  <?php
				  
				                //Section for your massages
				  
				                 $member_id=$_SESSION["logged"];
                                 $query = mysql_query("SELECT * FROM messages WHERE sender_id = '$member_id' ORDER BY messageid DESC");
                                 if(mysql_num_rows($query) > 0) 
								 
								 {
								 
								 
                                 while($row = mysql_fetch_array($query)) 
								 
								 { 
								 
								 
                                 $_query = mysql_query("SELECT * FROM member WHERE member_id = '" . $row["sender_id"] . "' ");
                                 while($_row = mysql_fetch_array($_query)) 
								 
								 {
								 
								
               
			                     echo '
			                    
								  <div id="messages_div">
								  
								  <div id="sender_info" >'.$_row['firstname']." ".$_row['secondname'].'</div>
								
			                     <img src="uploads/'.$_row['profile_picture'].'" id="sender_pic"  />
			                     
								 
								 <div id="messsage_text">'.$row['message'].' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								  '.$row['date'].'</div>
								 
			                      </div>
     								  ';
			                     }
						    }
							
						   
						   }else{
						            echo"<div id='messages_div'>";
						           
									echo 'You do not have message';
									
									echo"</div>"; 
										}
                                    
                                
									 
                             ?>
							 
							 
							 <div id="message1">
							 
							 <p id="receive_message" >Message you received</p>
							 
							  <?php
				  
				                //Section for showing those who message you
				  
				                  $member_id=$_SESSION["logged"];
                                 $query = mysql_query("SELECT * FROM messages WHERE receiver_id='$member_id' ORDER BY messageid DESC");
                                 if(mysql_num_rows($query) > 0) 
								   
								   
								 {
								 
								  
                                 while($row = mysql_fetch_array($query)) 
								 
								   
								 { 
								 
								 $sender=$row['sender_id']; 
								 
                                 $_query = mysql_query("SELECT * FROM member WHERE member_id = '$sender' ");
                                 while($_row = mysql_fetch_array($_query)) 
								 
								 {
								 
								
               
			                     echo '
			                    
								  <div id="messages_see">
								  
								  
								  
								  <div id="receiver_info" >'.$_row['firstname']." ".$_row['secondname'].'</div>
								
			                     <img src="uploads/'.$_row['profile_picture'].'" id="receiver_pic" />
			                     
								<div id="receiver_text" >'.$row['message'].' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								 '.$row['date'].'</div>
								
								
			                      </div>
     								  ';
			                     }
						    }
							
						   
						   }else{
						            echo"<div id='messages_see'>";
						           
									echo 'No person has send you a message';
									
									echo"</div>"; 
										}
                                      
									
                             ?>
							</div> 
						
					  
					  
					  
					  
					  <!--search engine--> 
                 <div id="noticeboard">
                          <div class="content">
                          <input type="text" class="search" id="searchid" placeholder="Search for people" />
	                      &nbsp; &nbsp; It is free and always will it be.<br /> 
                       <div id="result">
                         </div>
                       </div>
					   
					   </div>
				    <!-- end ofsearch engine-->
					   
					   
					   
              </body>
         
		    </html>

