                            
							
		 
		 
		 <?php
               include("function.php");
			   include("connection.php");
						
		?>
						
						
		     <?php
				  
				      /* section for counting messages you have sent */          
                                    
                      $member_id=$_SESSION["logged"];
					  
					  $vieww= mysql_query("SELECT * FROM messages WHERE sender_id = '$member_id'")or die(mysql_error());
						$counter = 0;
						WHILE($stat = mysql_fetch_array($vieww)){
						$counter++;
						}
						$allview = $counter;
					  
					      echo"<p style='font-size:15px; position:absolute; left:320px; top:73px;color:red;'> &nbsp;($allview)</p>";
									 
            ?>
							 
		   

		   <?php
				  
				       /* section for counting messages you have received */         
                                    
                      $member_id=$_SESSION["logged"];
					  
					     $vieww= mysql_query("SELECT * FROM messages WHERE receiver_id = '$member_id'")or die(mysql_error());
						$counter = 0;
						WHILE($stat = mysql_fetch_array($vieww)){
						$counter++;
						
						}
						
						$allview = $counter;
					  
					    echo"<p style='font-size:15px; position:absolute; left:670px; top:70px;color:red;'> &nbsp;($allview)</p>";
									 
           ?>