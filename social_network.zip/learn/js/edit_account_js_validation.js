

 function validate()
   {
   var x=document.myForm.firstname.value;
   if(x=="")
   {
   alert("First name must be filled out");
   return false;
   }
   }
   
   
  

 function validate_secondname()
   {
   var s=document.secondname_form.secondname.value;
   if(s=="")
   {
   alert("second name must be filled out");
   return false;
   }
   }
   
	function validate_password()
   {
	var p=document.password_form.password.value;
	if(p=="")
	 {
	 alert("password must be filled out");
	 return false;
	 
	 }
	 
	}

	function validate_email()
   {
   var e=document.email_form.email.value;
  if(e=="")
    {
	alert("email must be filled out");
	return false;
	}
	
	
   
	 var x=document["email_form"]["email"].value;
     var atpos=x.indexOf("@");
      var dotpos=x.lastIndexOf(".");
      if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
  
  
   }
