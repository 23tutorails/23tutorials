





              ///The below code is for validating the post text that you and your friends share

	            function validate()
             {
            var x=document.post_comment.commenttext.value;
                if(x=="")
              {
            alert("Post text area is empty");
             return false;
               }
            }	
  
              