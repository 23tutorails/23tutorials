

<!--  Section for inserting post into database on welcome page-->

<?php

              if (isset($_POST['submit_post']))
			{  
                  $sendcomment=$_POST['commenttext'];

                  $sender= $_SESSION["logged"];


                 mysql_query("INSERT INTO post(commenttext,date,me) VALUES('$sendcomment',NOW(),'$sender') ") or
                 die(mysql_error());
                 {
	             	echo "<script type=\"text/javascript\">
							alert(\"post added\");
							window.location='home.php';
							
						</script>";
			     }
            }
          ?>
		   
		  
		   <!--  Section for inserting comment into database on welcome page-->
		      
		<?php
                 if (isset($_POST['submit_comment']))
			       { 

                        $validat=$_POST['comment'];
							 
					if($validat==""){
					
								   
					echo "<script type=\"text/javascript\">
						          	alert(\"comment field is empty\");
							         window.location='home.php';
						          </script>";
								
								
								}
								else{
							   
                     $sendcomment=$_POST['comment'];

                     $sender= $_SESSION["logged"];
                     $post_id=$_POST['postid'];

                     $query=mysql_query("INSERT INTO postcomments(comment,date,memberid,postid) VALUES('$sendcomment',NOW(),'$sender','$post_id') ") or
                     die(mysql_error());
					 while($row=mysql_query($query)){
					 $sendcomment=$row['comment'];
	 
                    	 
		                    echo "<script type=\"text/javascript\">
						          	alert(\"comment added\");
							         window.location='home.php';
						          </script>";
			               }
			          }	

         }					  
         ?>  
		 
		 