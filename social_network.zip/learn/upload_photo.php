                  
				  <?php

              session_start();
               include("connection.php"); // connect to the database
                include("function.php"); //get the id (member_id) for the login user

              ?>
				  
				  <?php
                    
                     $me= $_SESSION["logged"];


                     $path = "uploads/";


                     $valid_formats = array("jpg", "png", "gif", "bmp");
	                   if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		             {
			            $name = $_FILES['file']['name'];
			            $size = $_FILES['file']['size'];
			
			             if(strlen($name))
				     {
					       list($txt, $ext) = explode(".", $name);
					       if(in_array($ext,$valid_formats))
					      {
					if($size<(1024*1024))
						{
							$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
							$tmp = $_FILES['file']['tmp_name'];
							if(move_uploaded_file($tmp, $path.$actual_image_name))
								{
								mysql_query("UPDATE member SET profile_picture='$actual_image_name' WHERE member_id='$me'");
									
									
									echo "<script type=\"text/javascript\">
							                alert(\"photo has been uploaded\");
							               window.location='home.php';
						                 </script>";
								}
							else
								echo "<script type=\"text/javascript\">
							                alert(\"photo uploaded failed\");
							               window.location='home.php';
						                 </script>";
						}
						else
						echo "<script type=\"text/javascript\">
							                alert(\"photo uploaded too big\");
							               window.location='home.php';
						                 </script>";					
						}
						else
						echo "<script type=\"text/javascript\">
							                alert(\"photo uploaded invalid\");
							               window.location='home.php';
						                 </script>";	
				}
				
			else
				echo "<script type=\"text/javascript\">
							                alert(\" Seclect a photo\");
							               window.location='home.php';
						                 </script>";
				
			exit;
		}
?>