
   <?php

       session_start();
       include("connection.php"); // connect to the database
       include("function.php"); //get the id (member_id) for the login user
       include("include_friends.php"); // count the numbers of friends and request of the login user.



    ?>

        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
        <head>
        
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

       <!-- Below is the external css for styling the index page -->
		  <link rel="stylesheet" type="text/css" href="css/index.css"/>
          
		  
		  <!-- Below is the external css for styling the home page -->
		  <link rel="stylesheet" type="text/css" href="css/home.css"/>
		  
		  <!-- Below is the external css for styling the friends page -->
          <link rel="stylesheet" type="text/css" href="css/friends.css"/>	
 
	    

       </head>

          <body>

                 <table bgcolor="green" width="100%" height="80">
                      <tr>
                             <td id="header_text"> Easygoing</td>
                              
                      </tr>
                 </table>
				 
				         
						 
                             <?php
						 /* select the names of the login from the database*/
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$member_id' LIMIT 1");

                             echo "<table border='0px' id='profilename'>
                             ";

                             while($row = mysql_fetch_array($result))
                        {
                             echo "<tr>";
           
                             echo "<img src='uploads/".$row['profile_picture']."'  width='170px' height='170px' class='profile_picture'>";
                             echo "<td>" . $row['firstname'] . "</td >";
                             echo "<td>". $row['secondname'] ."</td>";
                             echo "</tr>";
                        }
                             echo "</table>";

                        
						?>           
                        
			          
				 
	                   <div id="upload_picture">
					   
					   <form action="upload_photo.php" enctype="multipart/form-data" method="post" id="photo_upload_form">
								
		               <input name="MAX_FILE_SIZE" type="hidden" value="1000000"> 
		               <input id="upload_file" name="file" type="file"><br><br>
															
		               <button type="button">Close</button> 
		               <button name="savephoto" type="submit">Save Photo</button>
									
	                   </form>	
					   
					   </div>
					   
					   <a href="home.php"><button id="logout">HOME</button></a>
					   
					   <a href="friends.php"><button id="view_friend">View friends and friends request</button></a>
					   
					   <a href="messages.php"> <button class="message_link" id="position_link1" >view message</button></a>
					   
					   <a href="edit_account.php"> <button class="message_link" id="position_link" >Edit account</button></a>
					   
					   
					   <p id="friend_request_title" >See friend reuest</p>
					   
					   
					      <div id="friend_request_main_div">     
						<?php
				  
				                //Section for showing friendship requests
				  
				                 $member_id=$_SESSION["logged"];
                                 $query = mysql_query("SELECT * FROM friendship WHERE receiver = '$member_id'");
                                 if(mysql_num_rows($query) > 0) 
								 
								 {
								 
								 
                                 while($row = mysql_fetch_array($query)) 
								 
								 { 
								 
								 
                                 $_query = mysql_query("SELECT * FROM member WHERE member_id = '" . $row["sender"] . "'");
                                 while($_row = mysql_fetch_array($_query)) 
								 
								 {
                                  
								 
								  
			                     echo '
			                         
									 <div id="friend_request">
									 
								  
			                    <img src="uploads/'.$_row['profile_picture'].'" id="friend_photo" />
			                     <div style="position:absolute; margin:10px 0px 0px 83px;"><a href="friendinfo.php?amifo='.$row["sender"].'">'.$_row['firstname']." ".$_row['secondname'].'</a> want to be friends with you</div>
			                      
								 <div id="shiftlinks"><a href="add_friend.php?accept=' .$row['sender'].' ">Accept</a></div>
			                     <div id="shiftlinks1"><a href="delete_friend_request.php?accept=' .$row['sender'].'">Reject</a></div>
                                 
								 <hr>
								  </div>';
								 }
	                             
	                           }
							  
							   
                           }else{  
						   
						   
						        echo"<div id='friend_request'>
						   
						   		You do not have any friend pending  </li>
									
                                  </div>";
									
								}

                            
					 ?>
					 
					 
					    
					</div>
					<div id="message1">
					 
					 <p style="position:absolute; color:green; margin: 9px 0px 0px 203px; font-size:20px;">Your friends</p>
					 
					
						 <?php
						    
							 $member_id=$_SESSION["logged"];							
								  $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$member_id' OR myfriends = '$member_id' ")or die(mysql_error());
								
							     $num_rows  =mysql_numrows($post);
							
							     if ($num_rows != 0 ){

							  	while($row = mysql_fetch_array($post)){
				
								$myfriend = $row['myid'];
								$member_id=$_SESSION["logged"];
								
								
								
									if($myfriend == $member_id){
									
										$myfriend1 = $row['myfriends'];
										$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend1'")or die(mysql_error());
										$friendsa = mysql_fetch_array($friends);
									  
									    echo"<div id='messages_div'>";
									
									echo '<a href=friendinfo.php?amifo='.$friendsa["member_id"].'><br>&nbsp;<img src="uploads/'. $friendsa['profile_picture'].'" class="friend_pic" height="50" width="50" style="position:relative; left:2px; top:-15px;">
									
									<p  class="friend_info">&nbsp;'.$friendsa['firstname'].' '.$friendsa['secondname'].' </p></a>
									
									<div id="myfriend"><a href="delete_friend.php?delete=' .$friendsa['member_id'].' ">Unfriend</a> </div> ';
									
									   echo'</div>';
									    
									
									}else{
										
										$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend'")or die(mysql_error());
										$friendsa = mysql_fetch_array($friends);
										
										 echo"<div id='messages_div1' style='' position:absolute;>";
										
										echo '<a href=friendinfo.php?amifo='.$friendsa["member_id"].'><br>&nbsp;<img src="uploads/'. $friendsa['profile_picture'].'" class="friend_pic" >
									
									        <p  class="friend_info">&nbsp;'.$friendsa['firstname'].' '.$friendsa['secondname'].' </p></a>
									
									          <div id="myfriend"><a href="delete_friend.php?delete=' .$friendsa['member_id'].' ">Unfriend</a></div> ';
									    
										  echo'</div>';
									
									}
									
								}
								
								
								
								}else{
								
								  echo"<div id='messages_div'>";
								  
									echo 'You don\'t have friends </li>';
										}
										
									echo'</div>';	
					 
					     ?>
					
					
					 
					 </div>
					 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
					   <div>
					     <?php
						    
							 	
					 
					     ?>						 
						  
						  
				</div>		  
					   
			</body>
        
		</html>

<!-- ON member.member_id=myfriends.myid WHERE myfriends='$myfriend' -->