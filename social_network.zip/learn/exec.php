

    <?php
    
	//below variables are being assign to names of input fields in the registration form.
	session_start();
    include('connection.php');
    $firstname=$_POST['firstname'];
    $secondname=$_POST['secondname'];
    $email=$_POST['email'];
    $sex=$_POST['sex'];
    $password=$_POST['password'];
	$photo=$_POST['profile_picture'];
	$day=$_POST['day'];
	$month=$_POST['month'];
	$year=$_POST['year'];
	
	//Below checks if the email already exist in the database
	
	$query = mysql_query("SELECT * FROM member WHERE `email`='$email' ");
    if(mysql_num_rows($query) > 0){
    echo"
    <script type=\"text/javascript\">
							alert(\"Please this email address already existed / try another email\");
							window.location='index.php';
						</script>

      ";

       }

      else{
	//Below insert the registered user information into the database when it has passed the above validation.
	 
    mysql_query("INSERT INTO member(firstname, secondname, email, sex, password, profile_picture, day, month, year)
	VALUES('$firstname', '$secondname', '$email', '$sex', '$password', '$photo', '$day', '$month', '$year')");
    header("location: home.php");
    mysql_close($con);
	
	//Create query
    
	$qry="SELECT * FROM member WHERE email='$email' AND password='$password'";
    $result=mysql_query($qry);
     
    //Check whether the query was successful or not
                 
	   if($result) 
	
	{
       
	   if(mysql_num_rows($result) > 0) 
		
    {
       //register Successful
       session_regenerate_id();
       $member = mysql_fetch_assoc($result);
       $_SESSION['SESS_MEMBER_ID'] = $member['member_id'];
       $_SESSION['SESS_FIRST_NAME'] = $member['email'];
       $_SESSION['SESS_LAST_NAME'] = $member['password'];
       session_write_close();
       exit();
	        
			
	}
   }
  }
    
	?>
	
	
     