<?php
       include('connection.php');
       if($_POST)
     {
       
	   $query= mysql_real_escape_string($_POST['search']);
       $sql = mysql_query("SELECT * FROM `member` WHERE `firstname` LIKE '%$query%' OR `secondname` LIKE '%$query%' LIMIT 0, 5 ") or die (mysql_error());
		            
	   $num_of_row   = mysql_num_rows($sql);
			         
	   if ($num_of_row > 0 ){
					 
	   while($row = mysql_fetch_array($sql))
					
    { 
						
	    $id = $row['member_id'];
						
	   echo "<img src='uploads/".$row['profile_picture']."' width='50' height='50' style='position:relative; margin:-6px 0px 0px 3px;'>";
						
	   echo "<a href='friendinfo.php?amifo=".$id."' style='color:blue; text-decoration:none;'>&nbsp;".  $row['firstname']."&nbsp;".$row['secondname']."</a>";
						
	   echo "<hr width='600px'>";
					
	 }
				
   }
				
	else
		
	{
			
	  echo "<font color='red' size='4' >No result found!</font>";
				
	}
            
  }
 
 ?>