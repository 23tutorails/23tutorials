
             <?php

              session_start();
               include("connection.php"); // connect to the database
                include("function.php"); //get the id (member_id) for the login user
               include("insert.php"); //insert the add comment, text to the database
 
              ?>
  
   
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <!-- Below is the external css for styling the index page -->
		  <link rel="stylesheet" type="text/css" href="css/index.css"/>
          
		  
		  <!-- Below is the external css for styling the home page -->
		  <link rel="stylesheet" type="text/css" href="css/home.css"/>
          
		  
		  <!-- Below is the external css for styling the post text div or box-->
		  <link rel="stylesheet" type="text/css" href="css/comment_div.css"/>
		  
		  <!-- Below is the external css for styling the edit account page-->
          <link rel="stylesheet" type="text/css" href="css/edit_account_div.css"/>
	 
	       <!-- Below is the external add post text validation in JavaScript -->
          <script type="text/javascript" src="js/add_post_js_validation.js"></script>
		  
		  <!-- Below is the external edit account validation in JavaScript -->
          <script type="text/javascript" src="js/edit_account_js_validation.js"></script>
  
          
		  <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
            <script type="text/javascript">
             $(function(){
             $(".search").keyup(function() 
              
			  { 
                 var searchid = $(this).val();
                 var dataString = 'search='+ searchid;
                 if(searchid!='')
              {
	             $.ajax({
	             type: "POST",
	             url: "search.php",
	             data: dataString,
	             cache: false,
	             success: function(html)
	          {
	             $("#result").html(html).show();
	          }
	             });
                }return false;    
                });

                jQuery("#result").live("click",function(e){ 
	            var $clicked = $(e.target);
	            var $name = $clicked.find('.name').html();
	            var decoded = $("<div/>").html($name).text();
	            $('#searchid').val(decoded);
                });
                jQuery(document).live("click", function(e) { 
	            var $clicked = $(e.target);
	            if (! $clicked.hasClass("search")){
	            jQuery("#result").fadeOut(); 
	            }
                });
                $('#searchid').click(function(){
	            jQuery("#result").fadeIn();
                });
                });
                </script>   

    

     </head>

         <body>

                 <!--header--> 
                 <table id="header">
                      <tr>
                             <td id="header_text"> Easygoing</td>
                              
                      </tr>
                  </table>
				 <!--End of header--> 
				 
				         <?php
						 /* select the names of the login from the database*/
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$member_id' LIMIT 1");

                             echo "<table border='0px' id='profilename'>
                             ";

                             while($row = mysql_fetch_array($result))
                        {
                             echo "<tr>";
           
                             echo "<img src='uploads/".$row['profile_picture']."' class='profile_picture'>";
                             echo "<td>" . $row['firstname'] . "</td >";
                             echo "<td>". $row['secondname'] ."</td>";
                             echo "</tr>";
                        }
                             echo "</table>";


                       
                        
						?>           
				 
	                   <div id="upload_picture">
					   
					   <form action="upload_photo.php" enctype="multipart/form-data" method="post" id="photo_upload_form">
								
		               <input name="MAX_FILE_SIZE" type="hidden" value="1000000"> 
		               <input id="upload_file" name="file" type="file"><br><br>
															
		               <button type="button">Close</button> 
		               <button name="savephoto" type="submit">Save Photo</button>
									
	                   </form>	
					   
					   </div>
					   
					   <a href="home.php"><button id="logout">Home</button></a>
					   
					   <a href="friends.php"><button id="view_friend">View friends and friends request</button></a>
					   
					   <a href="messages.php"> <button class="message_link" id="position_link1" >view message</button></a>
					   
					   <a href="edit_account.php"> <button class="message_link" id="position_link" >Edit account</button></a>
					 
					 
					   
					  <p id="position_link3" >people you may know</p>
					   
					   <div id="people_you_know">
					   
					   
					   <?php
					    
						/* people you may know script */
						
						$member_id=$_SESSION["logged"];
						
						/* below selecct from the database friend that you may know them */
						$result= mysql_query("select * FROM `member` WHERE `member_id`!='$member_id' LIMIT 4");
						while($row=mysql_fetch_array($result))
						  
						   {
						     $memberid = $row["member_id"];
									    
						    echo'<div align="left"><img src="uploads/'.$row['profile_picture'].'" id="people_you_know_image" /></div>';
							echo'<div align="center"><a href="friendinfo.php?amifo='.$row["member_id"].'">'.$row['firstname']." ".$row['secondname'].'</a></div> ';
							echo'<div align="left">'."<input type='hidden' id=".$row['secondname'].'"></div> <br>';
							
							/* below check if the friend is already your friend */
							
							$member_id=$_SESSION["logged"];							
						    $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$member_id' AND myfriends='$memberid' OR myfriends = '$member_id' AND myid='$memberid'")or die(mysql_error());
								
							$num_rows  =mysql_numrows($post);
							
							if ($num_rows != 0 ){

							while($row = mysql_fetch_array($post)){
				
						    $myfriend = $memberid;
							$member_id=$_SESSION["logged"];
								
							if($myfriend == $member_id){
									
							$myfriend1 = $row['myfriends'];
							$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend1'")or die(mysql_error());
							$friendsa = mysql_fetch_array($friends);
									  
							echo" <div id='button_style'>Friends</div> ";
                            echo'<hr class="line_1"> ';
									    
							}else{
										
							$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend'")or die(mysql_error());
							$friendsa = mysql_fetch_array($friends);
							
							/* If the person is your friend the div having this id button_style will be seen. */
							
							echo" <div id='button_style'>Friends</div> ";
                             echo'<hr class="line_1"> ';
									
							}
									
								}
								
								
								
								} else
							
							{
							
							/* else if the person is not your fiend the link below will appear.*/
						    echo'<a href="process.php?send='.$row['member_id'].'" ><div id="button_style1">Add Friend</div></a>';
										
							echo'<hr class="line_1" "> ';
							echo'<br>';
								
							
						    }
							
							}
							
						?>   
					   
					   </div> 
					  
					   <!-- Div for posting text and photo on timeline and friends-->
					   <div id="posting_div">
				          <form action="home.php" METHOD="POST" onsubmit="return(validate())" name="post_comment">
					
				          <div class="UIComposer_Box">
                          <textarea id="watermark" class="input"  placeholder="What is on your mind." name="commenttext" ></textarea>


                           </div>
					       <input type="submit" name="submit_post" value="Post" id="post_button">
				            </form> 
							<!--  End of Form for sharing post-->
							
							
							<!-- below is the form for uploading a photo that you will share-->
							<form action="share_photo.php" enctype="multipart/form-data" method="post" id="share_upload_photo" >
								
		                    <input name="MAX_FILE_SIZE" type="hidden" value="1000000"> 
		                    <input id="upload_file" name="file" type="file"><br>
														
		                    <button name="savephoto" type="submit" id="style_upload_button">Save Photo</button>
									
	                          </form>	
				      </div>
						
						<!--section for edit form-->
					   
					   <div id="edit_account_div">
					          <p id="edit_accounter_header">Edit your personal information</p>
				       		
							<form name="myForm" id="firstnmae_form" action="insert_info.php" method="post" onsubmit="return(validate());" >
							   <input type="text" name="firstname" placeholder="Fill First Name" class="style_form">
							   <input type="submit" value="submit" name="firstname_submit" class="style_button">
							</form>
							
							<form name="secondname_form" id="secondname_form" action="insert_info.php" method="post" onsubmit="return(validate_secondname());">
							   <input type="text" name="secondname" placeholder="Fill Second Name" class="style_form">
							   <input type="submit" value="submit" name="second_submit" class="style_button">
							</form>
							
							<form name="email_form" id="email_form" action="insert_info.php" method="post" onsubmit="return(validate_email());">
							   <input type="text" name="email" placeholder="Fill email" class="style_form">
							   <input type="submit" value="submit" name="email_submit" class="style_button">
							</form>
							
							
							<form name="password_form" id="password_form" action="insert_info.php" method="post" onsubmit="return(validate_password());">
							   <input type="text" name="password" placeholder="Fill password" class="style_form">
							   <input type="submit" value="submit" name="password_submit" class="style_button">
							</form>
							
							
		              </div>
					  
					  <!--search engine--> 
                      <div id="noticeboard">
                          <div class="content">
                          <input type="text" class="search" id="searchid" placeholder="Search for people" />
	                      &nbsp; &nbsp; Created by Easygoing group<br /> 
                       <div id="result">
                         </div>
                       </div>
					   
					   </div>
				    <!-- end ofsearch engine-->
					   
					   
					   
</body>
</html>
