<?php
        session_start();
        include("connection.php");
        include("function.php");
        $me=$_SESSION["logged"];

?>