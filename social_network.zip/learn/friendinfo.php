
  <?php
        session_start();
        include("connection.php"); // connect to the database
        include("function.php"); //get the id (member_id) for the login user
		
        $friend1=$_GET['amifo']; //the id(member_id) of the person that the login user is viewing his/her information

        $me=$_SESSION["logged"];  // the id(member_id) of the login user.
    ?>
	  
	  
     <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
      <html xmlns="http://www.w3.org/1999/xhtml">
        
     <head>
     <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	    <!-- Below is the external css for styling the index page -->
		  <link rel="stylesheet" type="text/css" href="css/index.css"/>
		  
		  <!-- Below is the external css for styling the friendinfo page -->
	      <link rel="stylesheet" type="text/css" href="css/friendinfo.css"/>
	 
	       <!-- Below is the external css for styling the friends page -->
	      <link rel="stylesheet" type="text/css" href="css/friends.css"/>
	 
	 
	    

     </head>

         <body>

                 <table bgcolor="green" width="100%" height="80">
                      <tr>
                             <td id="header_text"> Easygoing</td>
                              <td><a href="home.php"><button id="logout_button">HOME</button></a></td>
                      </tr>
                 </table><br>

				 <?php
						 
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$member_id' LIMIT 1");

                             echo "<table border='0px' id='profilename'>
                             ";

                             while($row = mysql_fetch_array($result))
                        {
                             echo "<tr>";
                             
                             echo "<img src='uploads/".$row['profile_picture']."'  id='profile_pic'>";
                             echo "<td>" . $row['firstname'] . "</td >";
                             echo "<td>". $row['secondname'] ."</td>";
                             echo "</tr>";
                        }
                             echo "</table>";


                       
                        
						?>     

						
					
                      <div id="user_info">
                             
					<?php
					
					     $post = mysql_query("SELECT * FROM member WHERE member_id = '$friend1' OR member_id = '$friend1'")or die(mysql_error());
					     $row = mysql_fetch_array($post); 
			        ?>
					
					 <?php echo '<img src="uploads/'.$row['profile_picture'].'" id="view_user_pic" />';?> 
					 
					 
		                 <p id="position_view_user_name">Name: &nbsp;<strong><?php echo $row['firstname']." ".$row['secondname'];?>&nbsp;&nbsp;</strong></p> 
		                 <p id="position_view_user_email">email:&nbsp; <strong><?php echo $row['email'];?></strong>&nbsp;&nbsp;</p>
						 <p id="position_view_user_date">Date of birth:&nbsp; <strong><?php echo $row['day'];?></strong>&nbsp;&nbsp;</p>
		                 <p id="position_view_user_month">Month of birth:&nbsp; <strong><?php echo $row['month'];?></strong>&nbsp;&nbsp;</p> 	
					     <p id="position_view_user_year">Year of birth:&nbsp; <strong><?php echo $row['year'];?></strong>&nbsp;&nbsp;</p>		
							&nbsp;&nbsp;
		                 
		                 <?php					  
					   
						  if($me==$friend1){
						  
						     }
							    else{
							 
							   $member_id=$_SESSION["logged"];							
						    $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$member_id' AND myfriends='$friend1' OR myfriends = '$member_id' AND myid='$friend1'")or die(mysql_error());
								
							$num_rows  =mysql_numrows($post);
							
							if ($num_rows != 0 ){

							while($row = mysql_fetch_array($post)){
				
						    $myfriend = $friend1;
							$member_id=$_SESSION["logged"];
								
							if($myfriend == $member_id){
									
							$myfriend1 = $row['myfriends'];
							$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend1'")or die(mysql_error());
							$friendsa = mysql_fetch_array($friends);
									  
							
                            
									    
							}else{
										
							$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend'")or die(mysql_error());
							$friendsa = mysql_fetch_array($friends);
							
					
                             
									
							}
									
								}
								
								
								
								} else
							
							{
						    echo'<a href="process.php?send='.$row['member_id'].'" id="add_friend"><div id="button_style1">Add Friend</div></a>';
										
							
							echo'<br>';
								
							
						    }
							
							}
						   ?>
						   
						   
						   <!--Below is the section for sending private message to a user-->
						   <?php	
						   
						       $postt = mysql_query("SELECT * FROM member WHERE member_id = '$friend1' ")or die(mysql_error());
					            $rowm = mysql_fetch_array($postt);
						   
                               $postt = mysql_query("SELECT * FROM member WHERE member_id = '$me' ")or die(mysql_error());
					            $roww = mysql_fetch_array($postt); 						   
					   
						  if($me==$friend1){
						  
						     }
							    else{
							 
							    echo"<p id='styling_meaasage_header'>Send a private message</p>
						   
						       <form action='message.php' method='post' onsubmit='return(validate())' id='styling_message_form' name='message'>
						        
								 <input type='text' name='message' size='49' 
								 placeholder='Text Message here' ><br><br>
								 
								 <input type='hidden' value=".$rowm['member_id']." name='receiver'> 
								 <input type='hidden' value=".$roww['member_id']." name='sender'> 
								<input type='submit' value='send'>
						   
						   </form>";
							
							}
						   ?>
						   
						   <p id="birth_day"><?php 
						   
						   $year = mysql_query("SELECT * FROM member WHERE member_id = '$friend1' ")or die(mysql_error());
					       $rowr = mysql_fetch_array($year); 	
						   
						    $user=$rowr['year'];
						   /*
						    echo "$user";  */
						   
						   echo"<br>";  
						   
						   $year=date("Y");
						   
						  /* echo"$year";   */
						   
						   $birth=$year-$user;
						   
						   echo"<br>";
						   
						   echo"$birth years old";
						   
						   ?></p>
						   
						   
						   
						   <p id="birthday_1"><?php 
						   
						   $year = mysql_query("SELECT * FROM member WHERE member_id = '$friend1' ")or die(mysql_error());
					       $rowr = mysql_fetch_array($year); 	
						   
						    $user=$rowr['month'];
							
							$userd=$rowr['day'];
							
							/*  echo" $userd"; */
							
							/* echo" $user";   */
						   
						    $monthd=date("d");
							
							/* echo" $monthd";  */
						   
						    $month=date("m");
							
						/*	echo"$month";  */
						   
						    if($month==$user AND $monthd==$userd){
						   
						   
						   
						   echo"<br>";
						   
						   echo"<p>happy birth day</p>";
						   }
						   ?></p>
						   
						   
		                
					  </div>	

                      	
						
				
                      <div id="friend_header">
					  
					  <?php
						 
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$friend1' LIMIT 1");

                            
                             while($row = mysql_fetch_array($result))
                        {
                            
                           
                             echo "<p id='styling_header_text'> ".$row['firstname'] . "  ".$row['secondname'] . "
							 Friend (s)</p>";
                             
                        }
                       
					   
						?>    
					  
					   
					  
					  </div>
					  
					   <!--Below is the div that shows the friends of the user you click -->
		             <div id="view_friends">
					 
					 <?php
						    
							 $member_id=$_SESSION["logged"];							
								  $post = mysql_query("SELECT * FROM myfriends WHERE myid = '$friend1' OR myfriends = '$friend1' ")or die(mysql_error());
								
							     $num_rows  =mysql_numrows($post);
							
							     if ($num_rows != 0 ){

							  	while($row = mysql_fetch_array($post)){
				
								$myfriend = $row['myid'];
								
								
								
								
									if($myfriend == $friend1){
									
										$myfriend1 = $row['myfriends'];
										
										
										$query = mysql_query("SELECT * FROM myfriends WHERE `myid`='$member_id' AND `myfriends`='$myfriend1' OR`myid`='$myfriend1' AND `myfriends`='$member_id'");
             
	                                        if(mysql_num_rows($query) > 0 ){
   
                                               $row = mysql_fetch_array($query); 

                                                  echo"your friend";

                                                 }elseif($myfriend1==$member_id){
												 
												 echo"you";
												 
												 }else{
												 
												 echo"Not you friend";
												 
												 }

                                            
										
										$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend1'")or die(mysql_error());
										$friendsa = mysql_fetch_array($friends);
									  
									    
									
									echo '<p><br>&nbsp;<img src="uploads/'. $friendsa['profile_picture'].'" class="profile_image">
									<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									'.$friendsa['firstname'].' '.$friendsa['secondname'].' </p>';
									       
										echo'<hr>';	
									
									
									}else{
										
										
										  $query = mysql_query("SELECT * FROM myfriends WHERE `myid`='$member_id' AND `myfriends`='$myfriend' OR`myid`='$myfriend' AND `myfriends`='$member_id'");
             
	                                         if(mysql_num_rows($query) > 0 ){
   
                                               $row = mysql_fetch_array($query); 

                                                  echo"your friend";

                                                 }elseif($myfriend==$member_id){
												 
												 echo"you";
												 
												 }else{
												 
												 echo"Not you friend";
												 
												 }

	                                           
										
										$friends = mysql_query("SELECT * FROM member WHERE member_id = '$myfriend'")or die(mysql_error());
										$friendsa = mysql_fetch_array($friends);
										
										
										
										echo '<p><br>&nbsp;<img src="uploads/'. $friendsa['profile_picture'].'" class="profile_image">
										<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										'.$friendsa['firstname'].' '.$friendsa['secondname'].' </p>';
										
										echo'<hr>';	
									
									}
								
								
								}
								
								
								
								}else{
								
								  
								  
									echo 'Do not have friends </li>';
										}
										
									
					 
					     ?>
					 
					 </div>
					 
					  <!--Below is the e post header div-->
					 <div id="post_header">
					  
					  <?php
						 
                            
                             $member_id=$_SESSION["logged"];		

                             $result = mysql_query("SELECT * FROM `member` WHERE `member_id`='$friend1' LIMIT 1");

                            
                             while($row = mysql_fetch_array($result))
                        {
                            
                           
                             echo "<p id='user_header_name'> ".$row['firstname'] . "  ".$row['secondname'] . "
							 Post (s)</p>";
                             
                        }
                             

						?>    
					  
					  </div>	
					  <!--Below is the script that select the user post from the database which you have click. -->
					  <div id="view_user_post_div">

                       <?php

                               
			                   $post = mysql_query("SELECT * FROM post WHERE me = '$friend1' ORDER BY post.date DESC")or die(mysql_error());
								
			                  
	                            while($row = mysql_fetch_array($post)){
								$member_id=$row["me"];
								
								 $id=$row["post_id"];
								 
								 $post_text=$row["commenttext"];
								  
								 $photoname=$row["photo_name"];
								
							  $user=mysql_query("SELECT * FROM member WHERE member_id='$member_id'");
		                          $roww = mysql_fetch_array($user);
							   
							   /* select the number of like from the database*/
							   
							   $view= mysql_query("SELECT * FROM view WHERE post_number = '$id'")or die(mysql_error());
											$counter = 0;
											WHILE($stat = mysql_fetch_array($view)){
											$counter++;
										}
										$allview = $counter;
										
								/* select the number of Dislike from the database*/
							   
							   $dislike_view= mysql_query("SELECT * FROM dislike WHERE post_number = '$id'")or die(mysql_error());
											$counter = 0;
											WHILE($stat = mysql_fetch_array($dislike_view)){
											$counter++;
										}
										$dislikeview = $counter;

							   
							     /* div for posting and commenting*/
						         echo"<div id='comment_Container'>";
							   
							   
                                 /* div commenting*/
                                 echo'<div id="comment_body" >';
                            
				          	     /* area showing posting messages*/
					             
								 
					             echo'<img src="uploads/'.$roww['profile_picture'].'" id="profile_photo" />';
					        	 echo'<p id="user_names">
								 <a href="friendinfo.php?amifo='.$roww["member_id"].'">'.$roww["firstname"].'&nbsp;'.$roww["secondname"].'&nbsp;&nbsp;&nbsp;
					        	 </a></p>';
								 
								 if($post_text)  
								 
								 {
                                 echo'<p id="post_text">'.$row["commenttext"].'</p>';
								 
								 /* placing the like and unlike results for a post text   */
								 echo"<p id='count_like'>($allview) likes </p>";
								   
								 echo"<p id='count_dislike'>($dislikeview) Dislikes </p>";
								 
								 /* placing the like and unlike links for a post text   */
								 echo'<a href="insert_like.php?post_id='.$row['post_id'].'" id="show_likes">like</a>';
								 
								 echo'<a href="insert_dlike.php?post_id='.$row['post_id'].'" id="show_dislikes">Dislike</a>';
								 
								 }
								 elseif($photoname)
								 {
						
								 
								 echo'<img src="share_upload/'.$row['photo_name'].'" id="view_share_photo"/>';
								 
								 /* placing the like and unlike results for a post text   */
								 
								 
								 
								 /* placing the like and unlike links for a post pictures   */
								 echo'<a href="insert_like.php?post_id='.$row['post_id'].'" id="photo_likes" >like</a>';
								 
								 echo'<a href="insert_dlike.php?post_id='.$row['post_id'].'" id="photo_dislikes">Dislike</a>';
								 
								 echo"<p id='show_Photo_like'>($allview) likes </p>";
								 echo"<p id='show_Photo_dislike'>($dislikeview) Dislikes </p>";
								 
								 }


                                  echo'</div>';
		
		                       /* end of div commenting*/
						 
						       $comment = mysql_query("SELECT * FROM postcomments WHERE postid='$id' ORDER BY date DESC");
                               while($rows = mysql_fetch_array($comment)){
						 
						       $commentid=$rows["memberid"];
							 
						      $postt=mysql_query("SELECT * FROM member WHERE member_id='$commentid'");
		                      $rowwd = mysql_fetch_array($postt);
					         
						  
						      /*  area showing comment that is related to each each post*/
                              echo'<img src="uploads/'.$rowwd['profile_picture'].'" id="user_comment_photo" />';
						      echo'<p id="user_comment_info">
							  <a href="friendinfo.php?amifo='.$rowwd["member_id"].'">'.$rowwd["firstname"].' '.$rowwd["secondname"].'</a></p>'; 
						      echo'<div id="comment_text">'.$rows["comment"].':<span style="color:#ccc;"> '.$rows["date"].'.</span></div>';
						      echo'<hr>';
						  
				                                                  }   
                             $myid=mysql_query("SELECT * FROM member WHERE member_id='$member_id'");
		                     $rowww = mysql_fetch_array($myid);
						  
						  /*  form for adding comment related to a post*/
						         echo'<form action="home.php" name="myForm" METHOD="POST" onsubmit="return validateForm()">';
						         echo'<img src="uploads/'.$rowww['profile_picture'].'" id="comment_user_info" />';
                                 echo'<input type="text" name="comment" placeholder="Add comment" id="add_comment_field">';
						         echo'<input type="hidden" value=" '.$row['post_id'].'" name="postid">';
						         echo'<input type="submit" name="submit_comment" value="send" id="comment_button">';
						         echo'</form>'; 
							   
							   
							    echo"</div><br>";
							   
							  }
				    	   
	                        ?>	
						
						
						      </div>
	                      
            
        </body>
        </html>

