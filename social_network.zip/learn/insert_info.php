
     <?php

          session_start();
          include("connection.php");
          include("function.php");
  
  
         $my_id= $_SESSION["logged"];
			 
              if (isset($_POST['firstname_submit']))
			{  
                  $firstname=$_POST['firstname'];

                 mysql_query("UPDATE member SET firstname='$firstname' WHERE member_id='$my_id' ") or
                 die(mysql_error());
                 {
	             	echo "<script type=\"text/javascript\">
							alert(\"Your first name has been updated\");
							window.location='home.php';
							
						</script>";
			     }
            }
          ?>
		  
		  <?php

     
          include("connection.php");
          include("function.php");
  
  
         $my_id= $_SESSION["logged"];
			 
              if (isset($_POST['second_submit']))
			{  
                  $secondname=$_POST['secondname'];

                 mysql_query("UPDATE member SET secondname='$secondname' WHERE member_id='$my_id' ") or
                 die(mysql_error());
                 {
	             	echo "<script type=\"text/javascript\">
							alert(\"Your second name has been updated\");
							window.location='home.php';
							
						</script>";
			     }
            }
          ?>
		  
		  
		  <?php

     
          include("connection.php");
          include("function.php");
  
  
         $my_id= $_SESSION["logged"];
			 
              if (isset($_POST['email_submit']))
			{  
                  $email=$_POST['email'];

                 mysql_query("UPDATE member SET email='$email' WHERE member_id='$my_id' ") or
                 die(mysql_error());
                 {
	             	echo "<script type=\"text/javascript\">
							alert(\"Your email has been updated\");
							window.location='edit_account.php';
							
						</script>";
			     }
            }
          ?>
		   
		   
		   <?php

     
          include("connection.php");
          include("function.php");
  
  
         $my_id= $_SESSION["logged"];
			 
              if (isset($_POST['password_submit']))
			{  
                  $password=$_POST['password'];

                 mysql_query("UPDATE member SET password='$password' WHERE member_id='$my_id' ") or
                 die(mysql_error());
                 {
	             	echo "<script type=\"text/javascript\">
							alert(\"Your password has been updated\");
							window.location='edit_account.php';
							
						</script>";
			     }
            }
          ?>