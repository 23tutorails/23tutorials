
        <?php

             session_start();
             include("connection.php");
             include("function.php");
      
	     ?>




         <?php
         
                $sender= $_SESSION["logged"];
                
				$post_id=$_GET['post_id'];

                mysql_query("INSERT INTO view(fan_id,post_number) VALUES('$sender','$post_id') ") or
                die(mysql_error());
				{
					
		                    echo "<script type=\"text/javascript\">
						          	alert(\"like added\");
							         window.location='home.php';
						          </script>";
			    }
          
		  ?>
		  
		 