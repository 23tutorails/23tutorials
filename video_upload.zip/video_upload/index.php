   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	 
		 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
		 
		 <script type="text/javascript" src="script/jquery.form.js"></script>
		 
		  <script type="text/javascript" >
		 
			//upload video
              $(document).ready(function() { 
		
                $('#img').live('change', function()			{ 
			           
				$("#preview").html('');
			    
				$("#preview").html('<img src="icons/loader.gif" alt="Uploading...."/>');
			
			$("#formphoto").ajaxForm({
						target: '#preview'
		
		      }).submit();
		
			  });
          
    		  }); 
              
			 </script>   

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">23tutorials. How youtube upload video</h1></td>
                               <a href="http//:www.23tutorials.com" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  <div class="upload-video-div">
						  
						  <div class="fileUpload">
                                
								<span class="custom-span">+</span>
                                
								<p class="custom-para">Add Videos</p>
        
		                        <form id="formphoto" method="post" enctype="multipart/form-data" action='videoupload.php'>
                               
							    <input type="file" name="photoname" id="img" class="upload"/>
								
								<input type="hidden" name="descripe" value=""/>
                              
							  </form>
                          
						  </div>

                         <div id='preview'>
                          
						   </div>
						  
						 
						  </div>
				  
	             
               </body>
                
	      </html>
		  
		