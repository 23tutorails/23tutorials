
   <?php

        //session_start();
               
		   include("connection.php"); // connect to the database
                
              //include("function.php");

    
              //$member_id= $_SESSION["logged"];
			  
			  //$firstname= $_firstname;
			  
			  //$secondname= $_secondname;
            

      $path = "videos/";

	 $video_formats = array("mp4");
	 
	 $valid_formats = array("mp4", "flv", "avi", "wmv" , "mpg");
	                     
	  if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
     
	    {
			
	    $photo_name = $_FILES['photoname']['name'];
			
		$size = $_FILES['photoname']['size'];
			
		  if(strlen($photo_name))
				
		{ 
		
		  list($txt, $ext) = explode(".", $photo_name);
					if(in_array($ext,$video_formats))
					{
					if($size<(1000000*1000000))
						{
							$video_name = $_FILES['photoname']['name'];
							$tmp = $_FILES['photoname']['tmp_name'];
							if(move_uploaded_file($tmp, $path.$video_name))
								{
								 mysql_query("INSERT INTO video_upload( raw_video_title, video_title, date)
	                              VALUES( '$video_name', '$video_name', NOW() )");
									
									//echo "<img src='uploads/".$image_name."'  class='preview'>";
									
									echo "<video width='560' height='426' controls class='preview'>
									
									<source src='videos/".$video_name."'  </video>";
									
									
								}
							else
								echo "failed";
						}
						else
						echo "Image file size max 10000 MB";					
						}
						else
						echo "Incorrect VIDEO format..";	
				}
				
			else
				echo "Choose a video please..!";
				
			exit;
		}
?>