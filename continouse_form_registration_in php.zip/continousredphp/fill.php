 
   <?php

              session_start();
               include("connection.php"); // connect to the database
                include("function.php");
              
     
              ?>
 
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="js/register_form_validation.js"></script>
	    

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">Easygoing continous registration tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  <br><br><br><br><br><br><br><br>
				  
				 
				 <div id="register_div">

               <h1>continue filling information</h1>
               <form name="myForm" action="continue_reg.php" onsubmit="return(validate());" method="post">
    
                <br>
                     <input type="text"  name="sex" placeholder="Gender" class="reg"><br>
                <br>
                <br>
                     <input type="text"  name="day" placeholder="Day of birth" class="reg"><br>
                <br>
                <br>
                     <input type="text" name="month" placeholder="Month of birth" class="reg"><br>
                <br>
    
                <br>
                 <td><input type="text"  name="year" placeholder="Year of birth" class="reg"><br>
                <br>
                 
                   
                   <td><input name="submit" type="submit" value="Submit" id="sum"/></td>
    
	               </form>
  
                   </div>	
	             
				 

                     
                   </body>
                
				   </html>
