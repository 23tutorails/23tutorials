

    <?php
    
	//below variables are being assign to names of input fields in the registration form.
	session_start();
    include('connection.php');
    $firstname=$_POST['firstname'];
    $secondname=$_POST['secondname'];
    $email=$_POST['email'];
    $sex=$_POST['sex'];
    $password=$_POST['password'];
	
	
	//Below insert the registered user information into the database when it has passed the above validation.
	 
    mysql_query("INSERT INTO member(firstname, secondname, email, sex, password)
	VALUES('$firstname', '$secondname', '$email', '$sex', '$password')");
    header("location: fill.php");
    mysql_close($con);
	
	//Create query
    
	$qry="SELECT * FROM member WHERE email='$email' AND password='$password'";
    $result=mysql_query($qry);
     
    //Check whether the query was successful or not
                 
	   if($result) 
	
	{
       
	   if(mysql_num_rows($result) > 0) 
		
    {
       //register Successful
       session_regenerate_id();
       $member = mysql_fetch_assoc($result);
       $_SESSION['SESS_MEMBER_ID'] = $member['member_id'];
       $_SESSION['SESS_FIRST_NAME'] = $member['email'];
       $_SESSION['SESS_LAST_NAME'] = $member['password'];
       session_write_close();
       exit();
	        
			
	}
   }
  
    
	?>
	
	
     