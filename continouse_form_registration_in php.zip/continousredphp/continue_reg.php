<?php
    session_start();
	
    include('connection.php');
	
	include("function.php");
  
  
  ?>
  
  <?php
    $my_id= $_SESSION["logged"];
    
     $sex=$_POST['sex'];
    
	$day=$_POST['day'];
	$month=$_POST['month'];
	$year=$_POST['year'];
    mysql_query("UPDATE member SET sex='$sex', day='$day', month='$month', year='$year' WHERE member_id='$my_id' ");
	
	
    header("location: home.php");
    
    ?>