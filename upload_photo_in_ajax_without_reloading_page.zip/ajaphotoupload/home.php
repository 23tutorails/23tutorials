 
 
 
  <?php

             
               include("connection.php"); // connect to the database
                
              ?>
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	   
	   
	   
	  <!-- Below is the external css for upload button-->
      <link rel="stylesheet" type="text/css" href="css/upload_button.css"/>
	  
	  <style>
	 
      </style>	   

        <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>
     
	     <script type="text/javascript" src="script/jquery.form.js"></script>
	  
     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> Easygoing tutorial</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				   
						 
				 <div id="register_div">

                  <p>Jquery and php photo upload</p>  <br><br>
               
			      
						  
						  <div class="fileUpload">
                                
								<span class="custom-span">+</span>
                                
								<p class="custom-para">Add Images</p>
        
		                        <form id="formphoto" method="post" enctype="multipart/form-data" action='upload_photo.php'>
                               
							   Upload your image <input type="file" name="photoname" id="img" class="upload"/>
                              
							  </form>
                          
						  </div>

                         <div id='preview'>
                          
						   </div>
						  
						  
						  </div>
				      
					   
					 
                   </body>
                
				   </html>

				   
				<script type="text/javascript" >
			//upload profile photo
              $(document).ready(function() { 
		
                $('#img').live('change', function()			{ 
			           
				$("#preview").html('');
			    
				$("#preview").html('<img src="icons/loader.gif" alt="Uploading...."/>');
			
			$("#formphoto").ajaxForm({
						target: '#preview'
		
		      }).submit();
		
			  });
          
    		  }); 
              
			 </script>   