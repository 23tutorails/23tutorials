
<?php

              session_start();
               include("connection.php"); // connect to the database
                

              ?>
				  
				  <?php
                    
                     $member_id= $_SESSION["logged"];


                     $path = "uploads/";

	              $photo_formats = array("jpg", "png", "gif", "bmp" , "PNG" , "JPG", "GIF");
	                     if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		     {
			
			        $photo_name = $_FILES['photoname']['name'];
			
			
			      $size = $_FILES['photoname']['size'];
			
			if(strlen($photo_name))
				{
					list($txt, $ext) = explode(".", $photo_name);
					if(in_array($ext,$photo_formats))
					{
					if($size<(9000*9000))
						{
							$image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
							$tmp = $_FILES['photoname']['tmp_name'];
							if(move_uploaded_file($tmp, $path.$image_name))
								{
								mysql_query("UPDATE member SET profile_picture='$image_name' WHERE member_id='$member_id'");
									
									echo "<img src='uploads/".$image_name."'  class='preview'>";
									
								}
							else
								echo "failed";
						}
						else
						echo "Image file size max 9 MB";					
						}
						else
						echo "Incorrect image format..";	
				}
				
			else
				echo "Choose an image..!";
				
			exit;
		}
?>