-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2016 at 11:20 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `script`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `secondname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `password` varchar(30) NOT NULL,
  `day` varchar(100) NOT NULL,
  `month` varchar(30) NOT NULL,
  `year` varchar(100) NOT NULL,
  `cover_page_photo` varchar(11) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `firstname`, `secondname`, `email`, `profile_picture`, `password`, `day`, `month`, `year`, `cover_page_photo`) VALUES
(13, 'derick', 'yuut', 'demi@gmail.com', 'p.jpg', 'mmmm', '', '', '', 'cover.jpg'),
(12, 'loyd', 'miriam', 'same@gmail.com', 'p.jpg', 'mmmm', '', '', '', 'cover.jpg'),
(11, 'paul', 'john', 'paul@gmail.com', 'p.jpg', 'hhhh', '', '', '', 'cover.jpg'),
(14, 'louis', 'smith', 'mmm', 'p.jpg', 'mmmm', '', '', '', 'cover.jpg'),
(15, 'micheal', 'buston', 'meel@gmail.com', 'p.jpg', 'mmmm', '', '', '', 'cover.jpg'),
(19, 'madrid', 'ronaldo', 'madrid@gmail.com', 'p.jpg', 'mmmm', '', '', '', 'cover.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
