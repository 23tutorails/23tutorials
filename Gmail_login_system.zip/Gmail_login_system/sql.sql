-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2016 at 10:56 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `script`
--

-- --------------------------------------------------------

--
-- Table structure for table `video_upload`
--

CREATE TABLE IF NOT EXISTS `video_upload` (
  `video_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `secondname` varchar(30) NOT NULL,
  `raw_video_title` varchar(1000) NOT NULL,
  `video_title` varchar(1000) NOT NULL,
  `description` varchar(100) NOT NULL,
  `date` varchar(30) NOT NULL,
  PRIMARY KEY (`video_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `video_upload`
--

INSERT INTO `video_upload` (`video_id`, `member_id`, `firstname`, `secondname`, `raw_video_title`, `video_title`, `description`, `date`) VALUES
(5, '', '', '', 'facebook_edit_account_x264.mp4', 'facebook_edit_account_x264.mp4', '', '2016-07-26 15:45:52'),
(6, '', '', '', 'facebook_chat_system_x264.mp4', 'facebook_chat_system_x264.mp4', '', '2016-07-26 15:46:42'),
(7, '', '', '', 'loginscript_x264.mp4', 'loginscript_x264.mp4', '', '2016-07-26 15:47:18');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
