<?php
	
	  //Start session
    session_start();
     
    //Include database connection details
    require_once('connection.php');
	
	
	 $password = mysql_real_escape_string($_POST['password']);
	 
	 $email= mysql_real_escape_string($_POST['email']);
	
	$query = mysql_query("SELECT * FROM member WHERE email='$email'  AND password='$password' ");
    if(mysql_num_rows($query) > 0){
	
	 $row = mysql_fetch_array($query);
	 
	$name = $row["firstname"];
	
	$pword = $row["password"];
	
	//Login Successful
    session_regenerate_id();
    $row = mysql_fetch_assoc($query);
    $_SESSION['SESS_MEMBER_ID'] = $row['member_id'];
	$_SESSION['SESS_LAST_NAME'] = $row['email'];
    $_SESSION['SESS_LAST_NAME'] = $row['password'];
    session_write_close();
	
    echo"
    <script type=\"text/javascript\">
							alert(\"Please this $name, $pword address exist\");
							window.location='home.php';
						</script>

      ";

       }else{
	   
	   
	    echo"
    <script type=\"text/javascript\">
							alert(\"Passwor does not exist\");
							window.location='validate-password.php';
						</script>

      ";
	   
	   
	   }
    
	?>