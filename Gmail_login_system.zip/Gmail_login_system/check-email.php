

    <?php
	
	  //Start session
    session_start();
     
    //Include database connection details
    require_once('connection.php');
	
	
	 $email= mysql_real_escape_string($_POST['email']);
	
	$query = mysql_query("SELECT * FROM member WHERE `email`='$email' ");
    if(mysql_num_rows($query) > 0){
    echo"
    <script type=\"text/javascript\">
							alert(\"Please this email address already existed / try another email\");
							window.location='validate-password.php';
						</script>

      ";

       }else{
	   
	   
	    echo"
    <script type=\"text/javascript\">
							alert(\"Email does not exist\");
							window.location='index.php';
						</script>

      ";
	   
	   
	   }
	   
	   
	   //Create query
    
	$qry="SELECT * FROM member WHERE email='$email'";
    $result=mysql_query($qry);
     
    //Check whether the query was successful or not
                 
	   if($result) 
	
	{
       
	   if(mysql_num_rows($result) > 0) 
		
    {
       //register Successful
       session_regenerate_id();
       $member = mysql_fetch_assoc($result);
       $_SESSION['SESS_MEMBER_ID'] = $member['member_id'];
       $_SESSION['SESS_FIRST_NAME'] = $member['email'];
       session_write_close();
       exit();
	        
			
	}
   }
	   
    
	?>
	
	
     