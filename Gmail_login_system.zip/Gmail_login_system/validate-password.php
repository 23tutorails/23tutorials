 
 
 
  <?php

              session_start();
               include("connection.php"); // connect to the database
                include("function.php");
              
     
              ?>
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	 
	 
	   
	    

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> Easygoing Registration tutorial</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				   
						 
				 <div id="login_div">
				 
				       <?php
				   
				         $member_id = $_SESSION["logged"];
						 
						 $email =  $_SESSION["email"];
						 
						 $qry="SELECT * FROM member WHERE member_id = '$member_id'";
                          $row=mysql_query($qry);
						  

                  echo'<h1>login</h1>';
			   
                     echo'<form name="loginform" action="check-password.php" method="post">';
    
                        echo' <input type="text" name="password" placeholder="Enter your password" class="user_email"><br>';
                         
						 echo"<input type='hidden' name='email' value='$email'>";
						 
						echo'<br>';
    
				           echo' <input name="submit" type="submit" value="Next" id="sumit"/>';
    
	               echo'</form>';
				   
				    ?>
				    <br><br>
				   
				  
  
                   </div>
					 
                   </body>
                
				   </html>
