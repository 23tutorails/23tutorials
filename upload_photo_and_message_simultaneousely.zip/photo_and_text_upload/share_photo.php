<?php
           include("connection.php");
          

         
            
		   $message_title=$_POST['photo_text'];
		   
            $path = "share_photo/";


            $valid_formats = array("jpg", "png", "gif", "bmp" , "JPG" , "PNG" , "GIF");
	       if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST")
		   {
			$name = $_FILES['file']['name'];
			$size = $_FILES['file']['size'];
			
			if(strlen($name))
				{
					list($txt, $ext) = explode(".", $name);
					if(in_array($ext,$valid_formats))
					{
					if($size<(50024*50024))
						{
							$actual_image_name = time().substr(str_replace(" ", "_", $txt), 5).".".$ext;
							$tmp = $_FILES['file']['tmp_name'];
							if(move_uploaded_file($tmp, $path.$actual_image_name))
								{
								mysql_query("INSERT INTO post_photo(photo_name,photo_text)
	                             VALUES('$actual_image_name', '$message_title')");
									
									
									
									echo "<script type=\"text/javascript\">
							                alert(\"photo has been uploaded\");
							               window.location='index.php';
						                 </script>";
								}
							else
								echo "<script type=\"text/javascript\">
							                alert(\"photo uploaded failed\");
							              window.location='index.php';
						                 </script>";
						}
						else
						echo "<script type=\"text/javascript\">
							                alert(\"photo uploaded too big\");
							               window.location='index.php';
						                 </script>";					
						}
						else
						echo "<script type=\"text/javascript\">
							                alert(\"photo uploaded invalid\");
							               window.location='index.php';
						                 </script>";	
				}
				
			else
				echo "<script type=\"text/javascript\">
							                alert(\" Seclect a photo\");
							              window.location='index.php';
						                 </script>";
				
			exit;
		}
?>