<?php


  include("connection.php");
    
       $id=$_GET['send'];
      $result = mysql_query("SELECT * FROM post WHERE post_id ='$id' ");
      while($row = mysql_fetch_array($result))
                        
					
                     
                    {
					 echo''.$row['post_id'].'';

                                         
					 
					 }
                   
					
         ?>  
             	  
					  
        