   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	   <!-- Below is the external css for styling the modal box-->
      <link rel="stylesheet" type="text/css" href="css/modal_box.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="js/register_form_validation.js"></script>
	    
		 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">Easygoing tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  
					    <div class="main_div">
					
					    <p style="position:absolute; top:2px; left:75px; color:grey;">Upload photo and text simultaneousely into the database.</p>
					
					      <!-- below is the form for uploading a photo that you will share-->
							<form action="share_photo.php" enctype="multipart/form-data" method="post" class="share_upload_photo" >
								
		                    <input name="MAX_FILE_SIZE" type="hidden" value="1000000"> 
							<input type="text" name="photo_text" placeholder="Add photo to the photo you want to upload" size="39" style="height:29;" class="input"><br><p></p>
					   
					   
		                    <input id="upload_file" name="file" type="file">
														
		                    <button name="savephoto" type="submit" id="style_upload_button">Save Photo</button>
									
	                          </form>	
						       <!--End of Form for sharing photo-->
				          </div>
				 
				         <div style="position:relative; top:-40px;">
							  

							  <?php
							  
							    
                                       include("connection.php");
									   
                                      $result = mysql_query("SELECT * FROM `post_photo` ");
                                         while($row = mysql_fetch_array($result))
										 
										 {
										      $id=$row["post_id"];
										 
											  
											  
										 echo"<div class='post_Container'>";
										 
										 
										 echo'<img src="share_photo/'.$row['photo_name'].'" width="50px" height="50px;" style="position:absolute; left:20px;"/>';
                                         
										 echo'<p style="position:absolute; left:90px;">'. $row['photo_text'] .'</p>';
										  
										 
										  echo"</div>";
										 
										 
										   }
										 
									   
										  
									
							    ?>  
  
							</div>
				 
				        
				 
	             
               </body>
                
	      </html>
	
