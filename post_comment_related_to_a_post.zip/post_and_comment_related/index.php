   
   
   
 
      <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

	  <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  
	  <!-- Below is the external css for styling the index page-->
      <link rel="stylesheet" type="text/css" href="css/index.css"/>
	  
	  
	    <!-- Below is the external registration validated form in JavaScript -->
	  <script type="text/javascript" src="js/register_form_validation.js"></script>
	    
		 <script type="text/javascript" src="script/jquery-1.8.0.min.js"></script>

     </head>

         <body>

                 <nav id="index_page_header">
                      <tr>
                             <td><h1> <span style="">Easygoing tutorial in php</h1></td>
                               <a href="" id="web_link">Click for more tutorials</a>
                      </tr>
                 </nav>
				  
				  
				  <div style="position:relative; top:220px;">
							   <?php
                                       include("connection.php");
									   
                                      $result = mysql_query("SELECT * FROM `post` ");
                                         while($row = mysql_fetch_array($result))
										 
										 {
 
										     $id=$row["post_id"];
										 
										 echo"<div class='post_Container'>";
										 
										  echo"<div class='sub_Container'>";
										 
                                         
										 echo"". $row['commenttext'] ."<br>";
										  
										 
										 echo"</div>";
										 
										 
										    $comment = mysql_query("SELECT * FROM comments WHERE postid='$id' ORDER BY postid");
                                           
										      while($rows = mysql_fetch_array($comment)){
						 
						       
						                   echo'<div class="comment_text" >'.$rows["comment"].'</span></div>';
						                
 										   echo'<hr>';
						  
				                                                  }
										 
										  
										  /*  form for adding comment*/
						               echo'<form action="insert_comment.php" name="myForm" METHOD="POST" onsubmit="return validateForm()">';
						              
                                         echo'<input type="text" name="comment" placeholder="Add comment" class="add_comment_field">';
						                echo'<input type="hidden" value=" '.$row['post_id'].'" name="postid">';
						             echo'<input type="submit" name="submit_comment" value="send" class="comment_button">';
						              echo'</form>'; 
										  
										  
										 // echo"ggggg";
										 echo"</div><br>"; 
										  
										  }
                               ?>  
  
							</div>
				  
				 
				 <div id="post_div">
					
                         <form action="exec.php" METHOD="POST" onsubmit="return(validate())" name="post_comment">
					
				          <div class="UIComposer_Box">
                          <textarea class="watermark" class="input"  placeholder=" &nbsp;&nbsp;What is on your mind." name="post_text" ></textarea>


                           </div>
					       <input type="submit" name="submit_post" value="Tweet"  class="post_button">
						   
						  
						   <div  class="count_div"></div>
						   
						   
				            </form>	
							
							</div>	
						
	             
               </body>
                
	      </html>
		  
		   <script>
	        $(document).ready(function(){
		
		   $('.watermark').on('keyup', function(){
			var username = $('.watermark').val();
			if (username.length >140) {
			
			jQuery(".post_button").attr('disabled', 'disabled'); 
			
			} else {
			   
			   jQuery(".post_button").removeAttr('disabled');
			   
			 }
			
			
		
		//count number of string
		  var text =$('.watermark').val();
		  
		  var maximun_text=140;
		  
		  var text_number = text.length;
		  
		  var count_text= maximun_text-text_number;
		  
		  		  
		  $('.count_div').html(count_text);
		
		
		});
		
	});
	</script>
	
	 <script>
	       $(document).ready(function(){
		
			var username = $('.watermark').val();
			if (document.location.reload) {
			
			jQuery(".post_button").attr('disabled', 'disabled'); 

			
			} 
		});
	
	</script>

	
	