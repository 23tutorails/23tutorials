 
           <?php

             
               include("connection.php"); // connect to the database
                
              ?>
 
 <!--  Section for inserting comment into database on welcome page-->
		      
		<?php
                 if (isset($_POST['submit_comment']))
			       { 

                        $validat=$_POST['comment'];
							 
					if($validat==""){
					
								   
					echo "<script type=\"text/javascript\">
						          	alert(\"comment field is empty\");
							         window.location='index.php';
						          </script>";
								
								
								}
								else{
							   
                     $sendcomment=$_POST['comment'];

                     
                     $post_id=$_POST['postid'];

                     $query=mysql_query("INSERT INTO comments(comment, postid) VALUES('$sendcomment', '$post_id') ") or
                     die(mysql_error());
					 
					 {
					
                    	 
		                    echo "<script type=\"text/javascript\">
						          	alert(\"comment added\");
							         window.location='index.php';
						          </script>";
			               }
			          }	

         }					  
         ?>  
		 
		 