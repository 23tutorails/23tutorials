<?php
include('connection.php');


$names=$_POST['post_text'];
$cap=ucwords($names);

  
mysql_query("insert into post(commenttext) values ('$cap')");

    {
	             	  echo "<script type=\"text/javascript\">
							
							alert(\"post $cap added \");
							
							window.location='index.php';
							
						</script>";
			        }


?>
